<?php

namespace App\Http\Controllers\Api;

use App\Helper\MyHelper;
use App\Http\Controllers\Controller;
use App\Http\Requests\AddAqarRequest;
use App\Http\Requests\UpdateAqarRequest;
use App\Http\Resources\AqarAdditionResource;
use App\Http\Resources\AqarCategoryResource;
use App\Http\Resources\AqarDetailsResource;
use App\Http\Resources\AqarKindResource;
use App\Http\Resources\AqarResource;
use App\Http\Resources\AqarStatisticsResource;
use App\Http\Resources\AqarTypeResource;
use App\Http\Resources\CityResource;
use App\Http\Resources\CompanyDetailsResource;
use App\Http\Resources\CompanyResource;
use App\Http\Resources\FinishingTypeResource;
use App\Http\Resources\NormalResource;
use App\Http\Resources\PackageResource;
use App\Http\Resources\PaymentMethodResource;
use App\Http\Resources\ProjectResource;
use App\Http\Resources\ProjectsResource;
use App\Http\Resources\RegionAqarDetailsResource;
use App\Http\Resources\RegionResource;
use App\Http\Resources\SliderResource;
use App\Http\Resources\SpecialResource;
use App\Models\AdsType;
use App\Models\Aqar;
use App\Models\AqarAddition;
use App\Models\AqarCategory;
use App\Models\AqarKind;
use App\Models\AqarType;
use App\Models\City;
use App\Models\Comment;
use App\Models\CommentReport;
use App\Models\FinishingType;
use App\Models\Package;
use App\Models\PaymentMethod;
use App\Models\Project;
use App\Models\Setting;
use App\Models\Slider;
use App\Models\User;
use App\my_helper\Helper;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;


class   AqarController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth:api')->except('home', 'addAqarForm', 'aqarDetails', 'searchForm', 'aqarTypes'
            , 'aqarDetailsForm', 'aqarStatistics', 'searchAqar', 'projects', 'searchProjectsFrom', 'companies', 'companyDetails', 'aqarsForSale');
    }

    public function home(Request $request)
    {
        $vipAqars = Aqar::where('ads_type_id', 2)->when($request->aqar_kind_id, function ($query) use ($request) {
            return $query->where('aqar_kind_id', $request->aqar_kind_id);

        })->when($request->aqar_category_id, function ($query, $val) {
            return $query->where('aqar_category_id', $val);
        })->when($request->region_id, function ($query, $val) {
            return $query->where('region_id', $val);
        })->when(request('price_from'), function ($query) {
            return $query->whereBetween('price', [request('price_from'), request('price_to')]);
        })->when(request('width_from'), function ($query) {
            return $query->whereBetween('width', [request('width_from'), request('width_to')]);
        })->with('region.city', 'adsType')->withCount('comments', 'likes')->latest()->take(10)->get();

        $specialAqars = Aqar::where('ads_type_id', 3)->when($request->aqar_kind_id, function ($query) use ($request) {
            return $query->where('aqar_kind_id', $request->aqar_kind_id);

        })->when($request->aqar_category_id, function ($query, $val) {
            return $query->where('aqar_category_id', $val);
        })->when($request->region_id, function ($query, $val) {
            return $query->where('region_id', $val);
        })->when(request('price_from'), function ($query) {
            return $query->whereBetween('price', [request('price_from'), request('price_to')]);
        })->when(request('width_from'), function ($query) {
            return $query->whereBetween('width', [request('width_from'), request('width_to')]);
        })->with('region.city', 'adsType')->withCount('comments', 'likes')->latest()->take(10)->get();

        $normalAqars = Aqar::where('ads_type_id', 1)->when($request->aqar_kind_id, function ($query) use ($request) {
            return $query->where('aqar_kind_id', $request->aqar_kind_id);

        })->when($request->aqar_category_id, function ($query, $val) {
            return $query->where('aqar_category_id', $val);
        })->when($request->region_id, function ($query, $val) {
            return $query->where('region_id', $val);
        })->when(request('price_from'), function ($query) {
            return $query->whereBetween('price', [request('price_from'), request('price_to')]);
        })->when(request('width_from'), function ($query) {
            return $query->whereBetween('width', [request('width_from'), request('width_to')]);
        })->with('region.city', 'adsType')->withCount('comments', 'likes')->latest()->take(10)->get();

        $sliderVips = Slider::whereType('vip')->orderBy('sort')->get()->take(4);
        $sliderSpecials = Slider::whereType('special')->orderBy('sort')->get()->take(4);
        $sliderNormal = Slider::whereType('normal')->orderBy('sort')->get()->take(4);

        $data['vipAqars'] = AqarResource::collection($vipAqars);
        $data['vipAqars_sliders'] = SliderResource::collection($sliderVips);

        $data['specialAqars'] = AqarResource::collection($specialAqars);
        $data['specialAqars_sliders'] = SliderResource::collection($sliderSpecials);

        $data['normalAqars'] = AqarResource::collection($normalAqars);
        $data['normalAqars_sliders'] = SliderResource::collection($sliderNormal);

        return api_response($data);
    }

    public function addAqarForm(Request $request)
    {
        $this->validate($request, [
            'aqar_type_id' => 'required|exists:aqar_types,id',
            'aqar_kind_id' => 'required|exists:aqar_kinds,id',
        ]);
        $aqarKind = AqarKind::all();
        $aqarTypes = AqarType::all();
        $aqarType = AqarType::find($request->aqar_type_id);
        $aqarCategories = $aqarType->aqarCategories()->get();
        $priceForRentRange = [100000, 200000, 300000, 400000, 500000, 600000, 700000, 800000, 900000, 1000000, 1250000, 1500000, 1750000];
        $priceForSaleRange = [1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000, 15000, 20000, 25000, 30000, 35000, 40000, 45000, 50000, 60000
                              , 70000, 80000, 90000, 100000, 125000, 150000, 175000, 200000, 225000, 250000, 275000, 300000, 325000, 350000, 375000, 400000];

        $widthForRentRange = [50, 100, 150, 200, 250, 300, 350, 400, 450, 500, 600, 700, 800, 900, 1000, 1100, 1200, 1300, 1400, 1500, 1600, 1700, 1800,
                              1900, 2000, 2500, 3000, 3500, 4000, 4500, 5000, 6000, 7000, 8000, 9000, 10000];
        $registered = [
            'yes'        => __('yes'),
            'no'         => __('no'),
            'recordable' => __('recordable'),
        ];
        $paymentMethods = [
            'cache'       => __('cache'),
            'installment' => __('installment'),
        ];
        $packages = Package::all();
        $paymentTypes = PaymentMethod::where('id', 3)->get();
        $cities = City::with('regions')->get();
        $propertyFeatures = AqarAddition::all();
        $finishingTypes = FinishingType::all();
        $rentType = [
            'monthly' => __('monthly'),
            'annual'  => __('annual'),
        ];

        $data['aqar_kinds'] = AqarKindResource::collection($aqarKind);
        $data['aqar_types'] = AqarTypeResource::collection($aqarTypes);
        $data['aqar_categories'] = AqarCategoryResource::collection($aqarCategories);
        $data['registered_in_the_real_estate'] = $registered;
        $data['payment_methods'] = $paymentMethods;
        $data['cities'] = CityResource::collection($cities);
        $data['property_additions'] = AqarAdditionResource::collection($propertyFeatures);
        $data['finishing_types'] = FinishingTypeResource::collection($finishingTypes);
        $data['rent_Type'] = array($rentType);
        $data['price_range'] = request('aqar_kind_id') == 2 ? $priceForSaleRange : $priceForRentRange;
        $data['width_range'] = $widthForRentRange;
        $data['packages'] = PackageResource::collection($packages);
        $data['payment_types'] = PaymentMethodResource::collection($paymentTypes);
        return api_response($data, __('Form of  Add aqar aqar'));
    }

    public function aqarDetails($id)
    {
        $aqar = Aqar::with('user', 'comments', 'features')->withCount('comments', 'likes')->find($id);
        if (!$aqar) {
            return api_response(null, __('aqar not found'))->setStatusCode(401);
        }
        $aqar->increment('views', 1);
        $otherAqars = Aqar::where('region_id', $aqar->region_id)->where('id', '!=', $aqar->id)->latest()->take(4)->get();

        $cities = City::with('regions')->get();
        $listOfCities = [];
        foreach ($cities as $key => $city) {
            $listOfCities[] = [
                'id'       => $city->id,
                'name'     => $city->name,
                'selected' => $city->id == $aqar->region->city->id ? 1 : 0,
            ];
        }
        $data['cities'] = $listOfCities;
        $data['aqar_details'] = new AqarDetailsResource($aqar);
        $data['other_aqars'] = AqarResource::collection($otherAqars);
        return api_response($data, 'Aqar details');
    }

    public function commentAqar(Request $request, $id)
    {
        $this->validate($request, [
            'comment' => 'required|max:255',
        ]);

        $user = auth('api')->user();
        $aqar = Aqar::find($id);

        if (!$aqar) {
            return api_response(null, __('This aqar is nou found'));
        }
        $user->comments()->create([
                                      'aqar_id' => $aqar->id,
                                      'comment' => $request->comment,
                                  ]);

        return api_response(null, __('Your comment has been added successfully'));
    }

    public function reportComment(Request $request)
    {
        $this->validate($request, [
            'aqar_id'    => 'required|exists:aqars,id',
            'comment_id' => 'required|exists:comments,id',
        ]);
        $user = auth('api')->user();

        $aqar = Aqar::find($request->aqar_id);
        $comment = Comment::find($request->comment_id);

        if (!$aqar || !$comment) {
            return api_response(null, __('Something error ,try again'));
        }
        $exists = CommentReport::where(['aqar_id' => $aqar->id, 'comment_id' => $comment->id, 'user_id' => $user->id])->exists();

        if ($exists) {
            return api_response(null, __('You reported this comment before'));
        }

        $user->commentReports()->create([
                                            'aqar_id'    => $aqar->id,
                                            'comment_id' => $comment->id,
                                        ]);

        return api_response(null, __('Your report has benn sent to administration successfully'));
    }

    public function addAqar(AddAqarRequest $request)
    {
        $dataRequest = $request->validated();
        $user = auth('api')->user();
        if ($user->package_id != null && $user->package_id == 1) {
            // dd($user->aqars->count());
            $aqarsCount = $user->aqars()->whereMonth('published_at', Carbon::now()->month)
                               ->whereYear('published_at', Carbon::now()->year)
                               ->count();
            $count = $user->aqars()->whereMonth('created_at', Carbon::now()->month)
                          ->whereYear('created_at', Carbon::now()->year)
                          ->count();

            if ($aqarsCount >= 5 || $count >= 5) {
                return api_response(null, __('Sorry you have reached to the maximum number of free ads in the month'), 0);
            }
        }
        $dataRequest['status'] = 'draft';
        $aqar = $user->aqars()->create($dataRequest);
        $aqar->code = 'Aq0' . $aqar->id;
        $aqar->save();

        if ($request->hasFile('photos')) {
            $images = $request->file('photos');
            foreach ($images as $image) {
                MyHelper::addPhotos($image, $aqar, 'aqars', 'images');
            }

        }
        if ($request->additions) {
            $aqar->features()->attach($request->input('additions'), []);
        }
        if ($user->aqars()->count() > 3) {
            $user->update(['ownership_level' => 'company']);
        }

        if ($user->package_id != null && $user->package_id == 1) {
        return api_response([
                                'has_package' => $user->package_id == null ? false : true
                            ], __('Congratulations, your ad will be published as soon as possible. You still have ') .
                               4 - $count . __('free ads that can be used during this month'));
        }
        return api_response([
                                'has_package' => $user->package_id == null ? false : true
                            ], __('Congratulations, your ad will be published as soon as possible'));

    }

    public function searchForm(Request $request)
    {
        $this->validate($request, [
            'aqar_kind_id' => 'required|exists:aqar_kinds,id',
            'aqar_type_id' => 'required_if:aqar_ind_id,1,2|exists:aqar_types,id',
        ]);
        $aqarKind = AqarKind::take(2)->get();
        $aqarTypes = AqarType::all();
        if ($request->aqar_type_id == 1 || $request->aqar_type_id == 2) {
            $aqarType = AqarType::find($request->aqar_type_id);
            $aqarCategories = $aqarType->aqarCategories()->get();
            $data['aqar_categories'] = AqarCategoryResource::collection($aqarCategories);
            $data['aqar_types'] = AqarTypeResource::collection($aqarTypes);
        }
        $priceForRentRange = [100000, 200000, 300000, 400000, 500000, 600000, 700000, 800000, 900000, 1000000, 1250000, 1500000, 1750000];
        $priceForSaleRange = [1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000, 15000, 20000, 25000, 30000, 35000, 40000, 45000, 50000, 60000
                              , 70000, 80000, 90000, 100000, 125000, 150000, 175000, 200000, 225000, 250000, 275000, 300000, 325000, 350000, 375000, 400000];

        $widthForRentRange = [50, 100, 150, 200, 250, 300, 350, 400, 450, 500, 600, 700, 800, 900, 1000, 1100, 1200, 1300, 1400, 1500, 1600, 1700, 1800,
                              1900, 2000, 2500, 3000, 3500, 4000, 4500, 5000, 6000, 7000, 8000, 9000, 10000];


        $cities = City::with('regions')->get();


        $data['aqar_kinds'] = AqarKindResource::collection($aqarKind);

        $data['cities'] = CityResource::collection($cities);

        $data['price_range'] = request('aqar_kind_id') == 2 ? $priceForSaleRange : $priceForRentRange;
        $data['width_range'] = $widthForRentRange;
        return api_response($data, __('Form of  search aqar aqar'));
    }

    public function myAds(Request $request)
    {
        $this->validate($request, [
            'status' => 'in:draft,published,rejected,unavailable,pending'
        ]);
        $user = auth('api')->user();
        $myAqars = $user->aqars()->where(function ($query) use ($request) {
            if ($request->has('status') && $request->status == 'draft') {
                $query->where('status', 'draft');
            } elseif ($request->has('status') && $request->status == 'pending') {
                $query->where('status', '=', 'pending');
            } elseif ($request->has('status') && $request->status == 'rejected') {
                $query->where('status', '=', 'rejected');
            } elseif ($request->has('status') && $request->status == 'unavailable') {
                $query->where('status', '=', 'unavailable');
            } else {
                $query->where('status', 'published');
            }
        })->withCount('comments', 'likes')->latest('updated_at')->paginate(10);

        return api_response(AqarResource::collection($myAqars), 'Aqar details');
    }

    public function deleteAds($id)
    {
        $user = auth('api')->user();
        $ads = $user->aqars()->where('id', $id)->first();
        if (!$ads) {
            return api_response(null, __('No ads found'));
        }
        //delete aqar additions
        if ($ads->features()->count()) {
            $ads->features()->detach();
        }

        //delete aqar comments
        if ($ads->comments()->count()) {
            $ads->comments()->delete();
        }

        //delete aqar likes
        if ($ads->likes()->count()) {
            $ads->likes()->detach();
        }


        // Delete  images  when delete an aqar
        if ($ads->images()->count()) {

            $photosOfAqar = $ads->images;
            foreach ($photosOfAqar as $image) {
                if (file_exists(public_path($image->url))) {
                    File::Delete(public_path($image->url));
                }
            }
            $ads->images()->delete();
        }

        // Delete aqar
        $ads->delete();
        return api_response(null, __('Deleted successfully'));
    }

    public function updateAds(updateAqarRequest $request, $id)
    {
        $user = auth('api')->user();
        $ads = $user->aqars()->where('id', $id)->first();

        if (!$ads) {
            return api_response(null, __('No ads found'));
        }

        $ads->update($request->validated());

        if ($request->additions) {
            $ads->features()->sync($request->input('additions'));
        }

        if ($request->hasFile('photos')) {
            //$ads->images()->whereIn('images.id', $request->deleted_photos)->delete();
            $images = $request->file('photos');
            foreach ($images as $image) {
                MyHelper::updatePhotos($image, $ads, 'aqars', 'images');
            }

        }
        return api_response(null, __('Updated successfully'));
    }

    public function aqarTypes()
    {
        return api_response(AqarTypeResource::collection(AqarType::all()));
    }

    public function searchAqar(Request $request)
    {
        $aqars = Aqar::when($request->aqar_kind_id, function ($query) use ($request) {
            return $query->where('aqar_kind_id', $request->aqar_kind_id);

        })->when($request->aqar_category_id, function ($query, $val) {
            return $query->where('aqar_category_id', $val);
        })->when($request->region_id, function ($query, $val) {
            return $query->where('region_id', $val);
        })->when($request->city_id, function ($query) {
            return $query->whereHas('region', function ($q) {
                return $q->whereHas('city', function ($query) {
                    return $query->where('id', request('city_id'));
                });
            });
        })->when($request->code, function ($query, $val) {
            return $query->where('code', $val);
        })->when(request('price_from'), function ($query) {
            return $query->whereBetween('price', [request('price_from'), request('price_to')]);
        })->when(request('width_from'), function ($query) {
            return $query->whereBetween('width', [request('width_from'), request('width_to')]);
        })->with('region.city', 'adsType')->withCount('comments', 'likes')
                     ->orderBy(adsType::select('id')->whereColumn('ads_types.id', 'aqars.ads_type_id'), 'desc')
                     ->latest()
                     ->paginate(10);

        return api_response(AqarResource::collection($aqars), 'List of aqars');
    }


    public function searchProjectsFrom()
    {

        $priceForSaleRange = [1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000, 15000, 20000, 25000, 30000, 35000, 40000, 45000, 50000, 60000
                              , 70000, 80000, 90000, 100000, 125000, 150000, 175000, 200000, 225000, 250000, 275000, 300000, 325000, 350000, 375000, 400000];

        $widthForRentRange = [50, 100, 150, 200, 250, 300, 350, 400, 450, 500, 600, 700, 800, 900, 1000, 1100, 1200, 1300, 1400, 1500, 1600, 1700, 1800,
                              1900, 2000, 2500, 3000, 3500, 4000, 4500, 5000, 6000, 7000, 8000, 9000, 10000];


        $cities = City::get();
        $projectsNames = Project::get();

        $data['cities'] = CityResource::collection($cities);
        $data['project_names'] = ProjectResource::collection($projectsNames);

        $data['price_range'] = $priceForSaleRange;
        $data['width_range'] = $widthForRentRange;
        $data['creation_status'] = [
            'pending'   => __('Pending'),
            'completed' => __('completed'),
        ];
        return api_response($data, __('Form of search projects'));
    }

    public function companies(Request $request)
    {
        $aqars = User::when($request->name, function ($query) {
            $query->whereHas('city', function ($query) {
                return $query->where('name->ar', \request('name'))
                             ->orWhere('name->en', \request('name'));
            });
        })->when($request->company_type, function ($query, $val) {
            return $query->where('company_type', $val);
        })->where('membership_level', 'company')->withCount('aqars')->latest()->paginate(10);

        return api_response(CompanyResource::collection($aqars), 'List of companies');
    }

    public function companyDetails($id)
    {
        $company = User::where('membership_level', 'company')->withCount('aqars')->find($id);
        if (!$company) {
            return api_response(null, __('company not found'))->setStatusCode(401);
        }
        $company->increment('views', 1);
        $myAqars = Aqar::where('user_id', $company->id)->latest()->take(3)->get();


        $aqars_count = $company->aqars()
                               ->selectRaw('*,count(id) as total,DATE_FORMAT(created_at,"%Y-%m") as month ')
                               ->groupBy('month')
                               ->get();

        $aqarsLikes = $company->likes()
                              ->selectRaw('*,count(like_user.user_id) as total,DATE_FORMAT(like_user.created_at,"%Y-%m") as month ')
                              ->groupBy('month')
                              ->get();

        $aqarsComments = $company->comments()
                                 ->selectRaw('*,count(id) as total,DATE_FORMAT(created_at,"%Y-%m") as month ')
                                 ->groupBy('month')
                                 ->get();

        $totalAqars = $aqars_count->pluck('total');
        $months = $aqars_count->pluck('month');

        $totalLikes = $aqarsLikes->pluck('total');
        $LikesMonths = $aqarsLikes->pluck('month');

        $totalComments = $aqarsComments->pluck('total');
        $CommentsMonths = $aqarsComments->pluck('month');

        $statistics = [
            'aqars_count'    => [
                'total'  => $totalAqars,
                'months' => $months
            ],
            'likes_count'    => [
                'total'  => $totalLikes,
                'months' => $LikesMonths
            ],
            'comments_count' => [
                'total'  => $totalComments,
                'months' => $CommentsMonths
            ],

        ];

        $data['company_details'] = new CompanyDetailsResource($company);
        $data['statistics'] = $statistics;
        $data['my_aqars'] = AqarResource::collection($myAqars);
        return api_response($data, 'company details');
    }

    public function aqarStatistics()
    {
        $statistics = [
            'purchase_order' => rand(1, 100),
            'for_sale'       => rand(1, 100),
            'prices'         => rand(1, 100),
        ];

        return api_response($statistics, 'statistics');
    }

    public function aqarDetailsForm($id, Request $request)
    {
        $this->validate($request, [
            'aqar_type_id' => 'exists:aqar_types,id',
        ]);
        $aqar = Aqar::with('user', 'comments', 'features')->withCount('comments', 'likes')->find($id);
        if (!$aqar) {
            return api_response(null, __('aqar not found'))->setStatusCode(401);
        }
        $aqar->increment('views', 1);
        $otherAqars = Aqar::where('region_id', $aqar->region_id)->where('id', '!=', $aqar->id)->latest()->take(4)->get();
        $data['aqar_details'] = new AqarDetailsResource($aqar);
        $data['other_aqars'] = AqarResource::collection($otherAqars);

//        $cities = City::with('regions')->get();
//        $listOfCities = [];
//        foreach ($cities as $key => $city) {
//            $regions = $city->regions;
//            $listOfCities[] = [
//                'id'       => $city->id,
//                'name'     => $city->name,
//                'selected' => $city->id == $aqar->region->city->id ? 1 : 0,
//                'regions' => RegionAqarDetailsResource::collection($regions)
//            ];
//        }


//        $aqarKinds = AqarKind::take(2)->get();
//        $listOfAqarKinds = [];
//        foreach ($aqarKinds as $key => $aqarKind) {
//            $listOfAqarKinds[] = [
//                'id'       => $aqarKind->id,
//                'name'     => $aqarKind->name,
//                'selected' => $aqarKind->id == $aqar->aqarKind->id ? 1 : 0,
//            ];
//        }

//        if ($request->has('aqar_type_id')) {
//            $aqarType = AqarType::find($request->aqar_type_id);
//        } else {
//            $aqarType = AqarType::find($aqar->aqar_type_id);
//        }
//
//        $aqarCategories = $aqarType->aqarCategories()->get();
//        $listOfAqarCategories = [];
//        foreach ($aqarCategories as $key => $aqarCategory) {
//            $listOfAqarCategories[] = [
//                'id'       => $aqarCategory->id,
//                'name'     => $aqarCategory->name,
//                'selected' => $aqarCategory->id == $aqar->aqarCategory->id ? 1 : 0,
//            ];
//        }
//
//        $aqarTypes = AqarType::all();
//        $listOfAqarTypes = [];
//        foreach ($aqarTypes as $key => $aqarType) {
//            $listOfAqarTypes[] = [
//                'id'       => $aqarType->id,
//                'name'     => $aqarType->name,
//                'selected' => $aqarType->id == $aqar->aqarType->id ? 1 : 0,
//            ];
//        }
//
//        $finishingTypes = FinishingType::all();
//        $listOfFinishingTypes = [];
//        foreach ($finishingTypes as $key => $finishingType) {
//            $listOfFinishingTypes[] = [
//                'id'       => $finishingType->id,
//                'name'     => $finishingType->name,
//                'selected' => $finishingType->id == $aqar->finishingType->id ? 1 : 0,
//            ];
//        }
//
//        $paymentMethods = [
//            'cache'       => 'cache',
//            'installment' => 'installment',
//            'selected'    => $aqar->payment_method,
//        ];
//
//        $data['cities'] = $listOfCities;
//        $data['aqar_kinds'] = $listOfAqarKinds;
//        $data['aqar_types'] = $listOfAqarTypes;
//        $data['aqar_categories'] = $listOfAqarCategories;
//        $data['finishing_types'] = $listOfFinishingTypes;
//        $data['payment_methods'] = $paymentMethods;

        return api_response($data, 'Aqar details');
    }

    public function aqar_statistics()
    {
        $user = auth('api')->user();
        $aqars = $user->Aqars()->when(\request('keyword'), function ($query, $val) {

            return $query->where('name->ar', 'like', '%' . $val . '%')
                         ->orWhere('name->en', 'like', '%' . $val . '%');
        })->where('status', 'published')->withCount('comments', 'likes', 'chats')->latest()->paginate(1);

        return api_response(AqarStatisticsResource::collection($aqars), 'List of aqars');
    }

    public function aqarsForSale($id)
    {
        $aqars = Aqar::where('aqar_kind_id', 1)->where('region_id', $id)->latest()->paginate(10);

        return api_response(AqarResource::collection($aqars), 'list of aqars');
    }

}

?>
