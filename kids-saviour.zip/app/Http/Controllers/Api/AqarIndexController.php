<?php

namespace App\Http\Controllers\Api;

use App\Helper\MyHelper;
use App\Http\Controllers\Controller;
use App\Http\Resources\AqarTypeResource;
use App\Http\Resources\CityResource;
use App\Models\Aqar;
use App\Models\AqarOrder;
use App\Models\AqarType;
use App\Models\City;
use App\Models\Price;

use App\Models\Region;
use Carbon\Carbon;
use Illuminate\Http\Request;


class AqarIndexController extends Controller
{

    public function AqarIndexForm()
    {
        $cities = City::with('regions')->get();
        $aqarTypes = AqarType::all();

        $data['cities'] = CityResource::collection($cities);
        $data['aqar_types'] = AqarTypeResource::collection($aqarTypes);
        return api_response($data, 'Form of aqar index');
    }

    public function aqarPrice(Request $request)
    {
        $this->validate($request, [
            'aqar_type_id' => 'required|exists:aqar_types,id',
            'region_id'    => 'required|exists:regions,id',
        ]);
        //$pricePerMeter = Price::where(['aqar_type_id' => $request->aqar_type_id, 'region_id' => $request->region_id])->first();
        $allOrders = AqarOrder::count();
        $allForSale = Aqar::whereStatus('published')->count();

        $purchaseOrders = AqarOrder::when(request('region_id'), function ($q) {
            $q->where('region_id', \request('region_id'));
        })->when(request('aqar_type_id'), function ($query) {
            $query->where('aqar_type_id', \request('aqar_type_id'));
        })->count();

        $aqarsPurchase = AqarOrder::when(request('region_id'), function ($q) {
            $q->where('region_id', \request('region_id'));
        })->when(request('aqar_type_id'), function ($query) {
            $query->where('aqar_type_id', \request('aqar_type_id'));
        })->selectRaw('*,count(id) as total,DATE_FORMAT(created_at,"%Y-%m") as month ')
                                  ->groupBy('month')
                                  ->get();

        $aqarsForSale = Aqar::when(request('region_id'), function ($q) {
            $q->where('region_id', \request('region_id'));
        })->when(request('aqar_type_id'), function ($query) {
            $query->where('aqar_type_id', \request('aqar_type_id'));
        })->whereStatus('published')
                            ->selectRaw('*,count(id) as total,DATE_FORMAT(created_at,"%Y-%m") as month ')
                            ->groupBy('month')
                            ->get();

        $lastMonth = Carbon::now()->startOfMonth()->subMonth(1);
        $currentMonth = Carbon::now()->startOfMonth();


        $averagePriceOne = Aqar::when(request('region_id'), function ($q) {
            $q->where('region_id', \request('region_id'));
        })->when(request('aqar_type_id'), function ($query) {
            $query->where('aqar_type_id', \request('aqar_type_id'));
        })->whereStatus('published')
                               ->select('price', 'published_at')
                               ->where('published_at', $currentMonth)
                               ->sum('price');

        $averagePriceGraph = Aqar::when(request('region_id'), function ($q) {
            $q->where('region_id', \request('region_id'));
        })->when(request('aqar_type_id'), function ($query) {
            $query->where('aqar_type_id', \request('aqar_type_id'));
        })->whereStatus('published')
                                 ->whereBetween('published_at', [$lastMonth, $currentMonth])
                                 ->selectRaw('*,count(id) as total,DATE_FORMAT(published_at,"%Y-%m") as month')
                                 ->groupBy('month')
                                 ->get();


        $averagePriceTwo = Aqar::when(request('region_id'), function ($q) {
            $q->where('region_id', \request('region_id'));
        })->when(request('aqar_type_id'), function ($query) {
            $query->where('aqar_type_id', \request('aqar_type_id'));
        })->whereStatus('published')
                               ->select('price', 'published_at')
                               ->where('published_at', $lastMonth)
                               ->sum('price');


        if ($averagePriceOne == 0){
            $averagePriceOne= 1;
        }
        $averagePrice = ($averagePriceTwo / $averagePriceOne) * 100;

        $forSale = Aqar::when(request('region_id'), function ($q) {
            $q->where('region_id', \request('region_id'));
        })->when(request('aqar_type_id'), function ($query) {
            $query->where('aqar_type_id', \request('aqar_type_id'));
        })->whereStatus('published')->count();

        $totalPrice = Aqar::when(request('region_id'), function ($q) {
            $q->where('region_id', \request('region_id'));
        })->when(request('aqar_type_id'), function ($query) {
            $query->where('aqar_type_id', \request('aqar_type_id'));
        })->select('price','published_at')->whereStatus('published')->sum('price');

        $totalWidth = Aqar::when(request('region_id'), function ($q) {
            $q->where('region_id', \request('region_id'));
        })->when(request('aqar_type_id'), function ($query) {
            $query->where('aqar_type_id', \request('aqar_type_id'));
        })->select('width','published_at')->whereStatus('published')->sum('width');
        //dd($allForSale);

        $purchaseOrder = round(($purchaseOrders / $allOrders) * 100);
        $ordersForSale = round(($forSale / $allForSale) * 100);

        $averagePricePerMeter =

        $statistics = [
            'purchase_order' => [
                'rate'        => MyHelper::status($purchaseOrder),
                'graph_total' => $aqarsPurchase->pluck('total'),
                'graph_month' => $aqarsPurchase->pluck('month'),
            ],
            'for_sale'       => [
                'rate'        => MyHelper::status($ordersForSale),
                'graph_total' => $aqarsForSale->pluck('total'),
                'graph_month' => $aqarsForSale->pluck('month'),
            ],
            'average_prices' => [
                'rate'        => MyHelper::status($averagePrice),
                'graph_total' => $averagePriceGraph->pluck('total'),
                'graph_month' => $averagePriceGraph->pluck('month'),
            ],
        ];

        $data['statistics'] = $statistics;
        $data['region'] = Region::find($request->region_id)->description;
        $data['average_price_per_meter'] = $totalWidth == 0 ? $totalPrice / 1 : $totalPrice / $totalWidth  ;

        return api_response($data, 'statistics');

//        return api_response([
//                                'price'  => $pricePerMeter->price ?? 0,
//                                'region' => Region::find($request->region_id)->first()->description,
//                            ]
//            , __('Average price per square meter'));
    }


}

?>
