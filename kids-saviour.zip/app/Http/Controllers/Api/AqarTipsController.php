<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\AqarResource;
use App\Http\Resources\AqarTipsResource;
use App\Http\Resources\ArticleDetailsResource;
use App\Http\Resources\ArticleResource;
use App\Http\Resources\ContactUsResource;
use App\Http\Resources\NormalResource;
use App\Http\Resources\SliderResource;
use App\Http\Resources\SpecialResource;
use App\Http\Resources\TagResource;
use App\Models\Aqar;
use App\Models\AqarTips;
use App\Models\Article;
use App\Models\Setting;
use App\Models\Tag;
use Illuminate\Http\Request;


class AqarTipsController extends Controller
{

    public function aqarTips()
    {
        $aqarTips = AqarTips::all();

        return api_response(AqarTipsResource::collection($aqarTips), 'List of aqar tips');
    }


    public function articles()
    {
        $articles = Article::when(request('category_id'), function ($q) {
            $q->where('aqar_tip_id', \request('category_id'));
        })->when(\request('name'), function ($q) {
            $q->where('name->ar', 'like', '%' . \request('name') . '%')
              ->orWhere('name->en', 'like', '%' . \request('name') . '%');
        })->when(\request('description'), function ($q) {
            $q->where('description->ar', 'LIKE', '%' . \request('description') . '%')
              ->orWhere('description->en', 'LIKE', '%' . \request('description') . '%');
        })->latest()->paginate(10);

        return api_response(ArticleResource::collection($articles), 'List of articles');
    }

    public function articleDetails($id)
    {
        $article = Article::with('tags')->find($id);
        if (!$article) {
            return api_response(null, __('article not found'));
        }

        $latestNews = Article::where('id', '!=', $article->id)->when(\request('keyword'), function ($q, $val) {
            return $q->where('name->ar', 'like', '%' . $val . '%')
                     ->orWhere('name->en', 'like', '%' . $val . '%')
                     ->orWhere('description->ar', 'like', '%' . $val . '%')
                     ->orWhere('description->en', 'like', '%' . $val . '%');
        })->latest()->take(3)->get();

        $tags = Tag::withCount('articles')->get();
        $data['article'] = new ArticleDetailsResource($article);
        $data['last_news'] = ArticleResource::collection($latestNews);
        $data['tags'] =TagResource::collection($tags);

        return api_response($data, 'Article details');
    }

}

?>
