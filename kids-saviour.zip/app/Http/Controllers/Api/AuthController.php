<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\AqarResource;
use App\Http\Resources\UserResource;
use App\Mail\ResetPassword;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\File;

class AuthController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth:api')->except('login', 'signup', 'social_login', 'activate', 'forget_password', '
        resetPassword', 'verifyCode');
    }

    public function signup(Request $request)
    {
        $this->validate($request, [
            'name' => 'required|min:2|max:150',
            'phone' => 'required|numeric|digits:11',
            'email' => 'required|email|regex:/(.+)@(.+)\.(.+)/i|max:50',
            'password' => 'required|min:7|max:15',
            'address' => 'required|max:150|min:3',
        ]);
        $data = $request->all();
        $data['password'] = bcrypt($request->password);
        $data['status'] = 1;
        $user = User::create($data);
        $user->access_token = auth('api')->login($user);
        $message = __('you have successfully registered');
        return api_response(new UserResource($user), $message);
    }

    public function login(Request $request)
    {
        $this->validate($request, [
            'email' => 'required',
            'password' => 'required'
        ]);

        $user = auth('api')->attempt($request->only(['email', 'password'])) ||
            auth('api')->attempt(['phone' => $request->email, 'password' => $request->password]);
        if ($user) {
            $user = auth('api')->user();
            $user->access_token = auth('api')->login($user);
            return api_response(new UserResource($user));
        }
        return api_response(null, __('Invalid credentials'), 0);
    }

    public function social_login(Request $request)
    {
        $user = User::where([
            'social_id' => $request->social_id,
            'social_type' => $request->social_type,
        ])->first();
        $this->validate($request, [
            'social_id' => 'required',
            'social_type' => 'required|in:facebook,gmail',
        ]);

        if ($user) {
            $this->validate($request, [
                'email' => 'nullable|unique:users,email,' . $user->id,
            ]);
        }
        if (!$user) {
            $user = new User();
            $user->social_id = $request->social_id;
            $user->social_type = $request->social_type;
            $user->email = $request->email ?? '';
            $user->first_name = $request->name ?? '';
            $user->type = 'user';
            $user->status = 1;
            $user->save();
            $user->access_token = auth('api')->login($user);
            return api_response(new UserResource($user));
        }
        $user->update([
            'social_id' => request('social_id'),
            'social_type' => request('social_type'),
            'email' => request('email')
        ]);
        $user->access_token = auth('api')->login($user);
        return api_response(new UserResource($user));
    }


    public function activate(Request $request)
    {
        $this->validate($request, [
            'phone' => 'required',
            'code' => 'required'
        ]);
        $user = User::where('phone', $request->phone)->first();
        if ($user && $code = $user->code()->where('code', $request->code)->first()) {
            $user->active = 'yes';
            $user->save();
            $code->delete();
            $user->access_token = auth('api')->login($user);
            return api_response(new UserResource($user), __("Your account activated successfully"));
        }
        return api_response(null, __('Invalid code'), 0);
    }


    public function forget_password(Request $request)
    {
        $this->validate($request, [
            'email' => 'required'
        ]);
        $user = User::where('email', $request->email)->first();
        if (!$user) {
            return api_response(null, __('This user not found'), 0);
        }

        $code = rand(1000, 9999);
        $user->update(['code' => $code]);
        try {
            Mail::to($user->email)
                ->bcc('techcubicsfirebase@gmail.com')
                ->send(new ResetPassword($user));
        } catch (\Exception $e) {
            return api_response(null, $e->getMessage());
        }
        return api_response(['Email' => $user->email, 'code' => $code], __("Reset password code sent to your phone"));
    }

    public function resetPassword(Request $request)
    {
        $this->validate($request, [
            'code' => 'required',
            'password' => 'required|confirmed'
        ]);

        $user = User::where('code', $request->code)->where('code', '!=', null)->first();

        if ($user) {
            $update = $user->update(['password' => bcrypt($request->password), 'code' => null]);
            if ($update) {
                return api_response(null, __('Password changed successfully'));
            } else {
                return api_response(null, __('An error occurred, try again'));
            }
        } else {
            return api_response(null, __('Invalid reset code'));
        }
    }

    public function verifyCode(Request $request)
    {
        $this->validate($request, [
            'email' => 'required',
            'code' => 'required'
        ]);
        $user = User::where('code', $request->code)->where('code', '!=', null)->where('email', $request->email)->first();
        if ($user) {
            return api_response(['email' => $user->email, 'code' => $user->code], __('Please enter your new password'));
        }
        return api_response(null, __('Invalid reset code'));
    }

    public function changePassword(Request $request)
    {
        $this->validate($request, [
            'password' => 'required|confirmed',
            'current_password' => 'required'
        ]);


        $user = auth('api')->user();

        if ($user) {
            if (Hash::check($request->current_password, $user->password)) {
                $user->password = bcrypt($request->password);
                if ($user->save()) {
                    return api_response(null, __('Password changed successfully'));
                } else {
                    return api_response(null, __('An error occurred, try again'));
                }
            } else {
                return api_response(null, __('Current password is not correct'));
            }
        } else {
            return api_response(null, __('An error occurred, try again'));
        }
    }

    public function updateProfile(Request $request)
    {
        $user = auth('api')->user();
        $this->validate($request, [
            'email' => 'nullable|email|unique:users,email,' . $user->id,
            'phone' => 'nullable|unique:users,phone,' . $user->id,
            'whatsapp' => 'nullable|numeric',
            'first_name' => 'max:100',
            'last_name' => 'max:100',
            'image' => 'nullable|image|mimes:png,jpg,jpeg,svg|max:2048',
        ]);

        $user = User::with('employee')->where('id', $user->id)->first();
        if ($user->membership_level == 'company') {
            $this->validate($request, [
                'company_name' => 'required|max:100',
                'company_type' => 'required|in:real_estate_marketer,real_estate_company,real_estate_developer',
                'city_id' => 'nullable|exists:cities,id',
                'description' => 'nullable',
                'address' => 'nullable',
                'website' => 'nullable|url',
                'facebook' => 'nullable|url',
                'instagram' => 'nullable|url',
                'linkedin' => 'nullable|url',
                'from' => 'nullable',
                'to' => 'nullable|required_with:from',
                'company_image' => 'nullable|image|mimes:png,jpg,jpeg,svg|max:2048',
            ]);
        }

        //update user data if not try to update phone
        $data = $request->except('image', 'company_image');
        $user->update($data);
        if ($request->hasFile('image')) {
            $old_file = optional($user)->image;
            if (file_exists(public_path($old_file))) File::delete(public_path($old_file));
            $destinationPath = public_path() . '/uploads/users/';
            $logo = $request->file('image');
            $extension = $logo->getClientOriginalExtension();
            $name = time() . '' . rand(11111, 99999) . '.' . $extension;
            $logo->move($destinationPath, $name);
            $user->image = 'uploads/users/' . $name;
            $user->save();
        }

        if ($request->hasFile('company_image')) {
            $old_file = optional($user)->company_image;
            if (file_exists(public_path($old_file))) File::delete(public_path($old_file));
            $destinationPath = public_path() . '/uploads/companies/';
            $logo = $request->file('company_image');
            $extension = $logo->getClientOriginalExtension();
            $name = time() . '' . rand(11111, 99999) . '.' . $extension;
            $logo->move($destinationPath, $name);
            $user->company_image = 'uploads/companies/' . $name;
            $user->save();
        }

        if ($request->hasAny('employee_name', 'job', 'employee_phone', 'another_employee_phone')) {
            $user->employee()->updateOrCreate(['company_id' => $user->id], [
                'name' => $request->employee_name ?? null,
                'job' => $request->job ?? null,
                'another_phone' => $request->another_employee_phone ?? null,
                'phone' => $request->employee_phone ?? null
            ]);
        }
        $data = new UserResource($user);

        $user->access_token = auth('api')->login($user);
        return api_response($data, __('Profile has been updated successfully'));
    }

    public function showProfile()
    {
        $user = auth('api')->user();
        $user = User::with('employee')->withCount('aqars')->where('id', $user->id)->first();
        $user->access_token = auth('api')->login($user);
        if ($user->membership_level == 'company') {
            $aqars_count = $user->aqars()
                ->selectRaw('*,count(id) as total,DATE_FORMAT(created_at,"%Y-%m") as month ')
                ->groupBy('month')
                ->get();

            $aqarsLikes = $user->likes()
                ->selectRaw('*,count(like_user.user_id) as total,DATE_FORMAT(like_user.created_at,"%Y-%m") as month ')
                ->groupBy('month')
                ->get();

            $aqarsComments = $user->comments()
                ->selectRaw('*,count(id) as total,DATE_FORMAT(created_at,"%Y-%m") as month ')
                ->groupBy('month')
                ->get();

            $totalAqars = $aqars_count->pluck('total');
            $months = $aqars_count->pluck('month');

            $totalLikes = $aqarsLikes->pluck('total');
            $LikesMonths = $aqarsLikes->pluck('month');

            $totalComments = $aqarsComments->pluck('total');
            $CommentsMonths = $aqarsComments->pluck('month');

            $statistics = [
                'aqars_count' => [
                    'total' => $totalAqars,
                    'months' => $months
                ],
                'likes_count' => [
                    'total' => $totalLikes,
                    'months' => $LikesMonths
                ],
                'comments_count' => [
                    'total' => $totalComments,
                    'months' => $CommentsMonths
                ],

            ];

            $allAqars = $user->aqars()->whereStatus('published')->latest()->paginate(10);
            $ourAqars = $user->aqars()->whereStatus('published')->take(3)->get();
            $data['user'] = new UserResource($user);
            $data['our_aqars'] = AqarResource::collection($ourAqars);
            $data['all_aqars'] = AqarResource::collection($allAqars);
            $data['statistics'] = $statistics;
            return api_response($data, 'success');
        } else {
            $data = new UserResource($user);
            return api_response($data, 'success');
        }
    }
}

?>
