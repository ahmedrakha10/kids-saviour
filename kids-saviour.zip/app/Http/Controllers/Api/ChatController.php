<?php

namespace App\Http\Controllers\Api;


use App\Http\Controllers\Controller;
use App\Http\Resources\ChatResource;
use App\Models\Chat;
use Illuminate\Http\Request;


class ChatController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth:api');
    }

    public function chatList()
    {
        $user = auth()->user();
        $rows = Chat::whereRaw('id in (SELECT MAX(id) FROM chats GROUP BY room)')
                    ->where(function ($query) use ($user) {
                        return $query->where("from_user_id", $user->id)
                                     ->orWhere("to_user_id", $user->id);
                    })->latest('updated_at')->paginate(40);
        return api_response(ChatResource::collection($rows));
    }


    public function sendMessage(Request $request)
    {
        $data = $request->validate([
                                       'to_user_id' => 'required|exists:users,id',
                                       'message'    => 'required',
                                       'aqar_id'    => 'required|exists:aqars,id',
                                   ]);
        $user = auth('api')->user();
        $data = $request->all();
        $data['from_user_id'] = $user->id;
        $user_ids = [$user->id, $request->to_user_id];
        sort($user_ids);
        $data['room'] = implode('-', $user_ids);
        $data['type'] = $request->type ?? 'text';
        if ($request->hasFile('image')) {
            $file = $request->file('image');
            //$data['message'] = $data['image'] = $request->image;
            $data['message'] = $file->store('uploads/chat/' . $request->room);
            $data['type'] = 'image';
            $message = Chat::create($data);
            return api_response(['room' => $message->room], __('Message Sent Successfully'));
        }
        $data['message'] = $request->message;
        $data['typed_id'] = $request->aqar_id;
        $data['typed_type'] = 'App\Models\Aqar';
        $data['message'] = $request->message;
        $message = Chat::create($data);


        return api_response(['room' => $message->room], __('Message Sent Successfully'));
    }

    public function showChat(Request $request)
    {

        $chat = Chat::where('room', $request->room)->forme();
        if (!$chat) {
            return api_response(null, __('not chat found'));
        }
        $rows = $chat->latest()->paginate(20);
        $chat->update(['seen' => 1]);
        return api_response(ChatResource::collection($rows));
    }

}

?>
