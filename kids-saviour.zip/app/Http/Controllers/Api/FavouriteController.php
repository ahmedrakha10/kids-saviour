<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\AqarResource;
use App\Http\Resources\NormalResource;
use App\Http\Resources\ServiceResource;
use App\Http\Resources\SliderResource;
use App\Http\Resources\SpecialResource;
use App\Models\Aqar;
use App\Models\Service;
use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class FavouriteController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth:api');
    }


    public function favouriteAqar(Request $request, $id)
    {
        $aqar = Aqar::find($id);
        if (!$aqar) {
            return api_response(null, __('Not aqar found'), 0);
        }
        $exists = DB::table('like_user')->where(['user_id' => auth('api')->user()->id, 'aqar_id' => $aqar->id])->first();
        $toggle = auth('api')->user()->likes()->toggle($aqar->id);

        return api_response($toggle, $exists
            ? __('aqar has been unliked successfully')
            :
            __('aqar has been liked successfully'), 1);


    }

    public function myLikes()
    {
        $aqars = auth('api')->user()->likes()->when(request('keyword'),function ($q) {
            $q->where('name->ar', 'like', '%' . \request('keyword') . '%')
              ->orWhere('name->en', 'like', '%' . \request('keyword') . '%');
        })->withCount('likes')->latest()->paginate(20);

        return api_response(AqarResource::collection($aqars), __('List of my liked aqars'), 1);
    }
}

?>
