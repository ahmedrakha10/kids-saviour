<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\OrderAqarRequest;
use App\Http\Resources\AqarKindResource;
use App\Http\Resources\AqarResource;
use App\Http\Resources\AqarTypeResource;
use App\Http\Resources\CityResource;
use App\Http\Resources\NormalResource;
use App\Http\Resources\PaymentMethodResource;
use App\Http\Resources\ServiceResource;
use App\Http\Resources\SliderResource;
use App\Http\Resources\SpecialResource;
use App\Models\Aqar;
use App\Models\AqarKind;
use App\Models\AqarOrder;
use App\Models\AqarType;
use App\Models\City;
use App\Models\PaymentMethod;
use App\Models\Service;
use App\Models\Setting;
use Illuminate\Http\Request;


class OrderController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth:api')->except('orderAqarForm');
    }

    public function orderAqarForm()
    {
        $aqarKind = AqarKind::all();
        $cities = City::with('regions')->get();
        $aqarTypes = AqarType::all();
        $paymentMethods = PaymentMethod::all();
        $rentType = [
            'monthly' => __('monthly'),
            'annual'  => __('annual'),
        ];

        $priceForSaleRange = [100000,200000,300000,400000,500000,600000,700000,800000,900000,1000000,1250000,1500000,1750000];
        $priceForRentRange = [1000,2000,3000,4000,5000,6000,7000,8000,9000,10000,15000,20000,25000,30000,35000,40000,45000,50000,60000
        ,70000,80000,90000,100000,125000,150000,175000,200000,225000,250000,275000,300000,325000,350000,375000,400000];

        $widthForRentRange = [50,100,150,200,250,300,350,400,450,500,600,700,800,900,1000,1100,1200,1300,1400,1500,1600,1700,1800,
            1900,2000,2500,3000,3500,4000,4500,5000,6000,7000,8000,9000,10000];

        $data['aqar_kinds'] = AqarKindResource::collection($aqarKind);
        $data['aqar_types'] = AqarTypeResource::collection($aqarTypes);
        $data['payment_methods'] = PaymentMethodResource::collection($paymentMethods);
        $data['cities'] = CityResource::collection($cities);
        $data['rent_Type'] = array($rentType);
        $data['price_range'] = request('aqar_kind_id') == 2 ? $priceForSaleRange : $priceForRentRange;
        $data['width_range'] = $widthForRentRange;
        return api_response($data, __('Form of order your aqar'));
    }

    public function orderAqar(OrderAqarRequest $request)
    {
        $dataRequest = $request->validated();

        AqarOrder::create($dataRequest);
        return api_response(null, __('Your order request has been successfully completed'));

    }

}

?>
