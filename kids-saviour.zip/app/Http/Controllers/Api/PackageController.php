<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\PackageResource;
use App\Http\Resources\ServiceResource;
use App\Models\Package;
use App\Models\Service;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class PackageController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth:api')->except('packages', 'pricing', 'packageDetails');
    }

    public function packages(Request $request)
    {
        if ($request->type == 'companies') {
            $packages = Package::where('type', 'companies')->latest()->get();
            return api_response(packageResource::collection($packages), 'list of  packages for companies');
        }

        $packages = Package::where('type', 'individual')->latest()->get();
        return api_response(PackageResource::collection($packages), __('List of packages for individual'));
    }

    public function orderPackage(Request $request)
    {
        $user = auth('api')->user();
        $this->validate($request, [
            'package_id' => 'required',
        ]);
        $package = Package::find($request->package_id);
        if (!$package) {
            return api_response(null, __('Not package found'), 0);
        }
        if (!$request->execute) {
            return api_response([
                                    'package_name' => $package->name,
                                    'period'       => $package->period ?? '',
                                    'position'     => $package->position ?? '',
                                    'views_number' => $package->views_number ?? '',
                                    'total_ads'    => $package->total_ads ?? '',
                                    'normal_ads'   => $package->normal_ads ?? '',
                                    'special_ads'  => $package->special_ads ?? '',
                                    'vip_ads'      => $package->vip_ads ?? '',
                                    'banner_ads'   => $package->banner_ads ?? '',
                                    'total_price'  => $package->price,
                                    'start_date'   => Carbon::now()->format('Y-m-d'),
                                    'end_date'     => Carbon::now()->addMonth()->format('Y-m-d'),
                                ], __('Package details'));
        }
        if ($user->orders()->count()) {
            $lastSubscribe = $user->orders()->get()->last();
            $endDate = $lastSubscribe->end_date;

            if ($endDate >= Carbon::now()->format('Y-m-d')) {
                return api_response(null, __('you already subscribed a package'));
            }
        }
//        if ($user->package_id != null) {
//            return api_response(null, __('you already subscribed a package'));
//        }

        $order = $user->orders()->create([
                                             'package_id'  => $package->id,
                                             'total_price' => $package->price,
                                             'status'      => 'pending',
                                             'start_date'  => Carbon::now()->format('Y-m-d'),
                                             'end_date'    => Carbon::now()->addMonth()->format('Y-m-d'),
                                         ]);
        $client = User::find($user->id);
        $client->update(['package_id' => $order->package_id]);
        return api_response(null, __('Your package request has been successfully completed'));

    }

    public function pricing()
    {
        $packages = Package::where('type', 'companies')->get();
        return api_response(packageResource::collection($packages), 'list of  packages for companies');

    }

    public function packageDetails($id)
    {
        $package = package::find($id);
        if (!$package) {
            return api_response(null, __('package not found'))->setStatusCode(401);
        }

        return api_response(new PackageResource($package), 'company details');
    }
}

?>
