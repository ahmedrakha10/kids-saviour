<?php

namespace App\Http\Controllers\Api;

use App\Helper\MyHelper;
use App\Http\Controllers\Controller;
use App\Http\Requests\AddProjectRequest;
use App\Http\Requests\AddProjectUnitRequest;
use App\Http\Resources\CityResource;
use App\Http\Resources\ProjectDetailsResource;
use App\Http\Resources\ProjectsResource;
use App\Http\Resources\UnitsResource;
use App\Models\Aqar;
use App\Models\City;
use App\Models\Comment;
use App\Models\CommentReport;
use App\Models\Project;
use App\Models\ProjectComment;
use App\Models\ProjectCommentReport;
use App\Models\Unit;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class ProjectController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth:api')->except('projects', 'addProjectForm', 'projectDetails', 'unitDetails');
    }

    public function addProject(AddProjectRequest $request)
    {
        $dataRequest = $request->validated();
        $user = auth('api')->user();

        $dataRequest['creation_status'] = 'pending';
        $project = $user->projects()->create($dataRequest);
        $project->code = 'Aqp00' . $project->id;
        $project->save();

        if ($request->hasFile('photos')) {
            $images = $request->file('photos');
            foreach ($images as $image) {
                MyHelper::addPhotos($image, $project, 'projects', 'images');
            }

        }
        if ($request->additions) {
            $project->additions()->attach($request->input('additions'), []);
        }
        return api_response([
                                'project_id' => $project->id
                            ], __('Project added successfully'));

    }

    public function projects(Request $request)
    {
        $projects = Project::when($request->name, function ($query) use ($request) {
            return $query->where('title->ar', $request->name)
                         ->orWhere('title->en', $request->name);

        })->when($request->city_id, function ($query) {
            $query->whereHas('region', function ($q) {
                $q->whereHas('city', function ($query) {
                    return $query->where('city_id', \request('city_id'));
                });
            });
        })->when($request->code, function ($query, $val) {
            return $query->where('code', $val);
        })->when($request->creation_status, function ($query, $val) {
            return $query->where('creation_status', $val);
        })->when(request('price_from'), function ($query) {
            return $query->whereBetween('price_from', [request('price_from'), request('price_to')]);
        })->when(request('width_from'), function ($query) {
            return $query->whereBetween('width_from', [request('width_from'), request('width_to')]);
        })->with('region.city')->withCount('comments', 'likes')->latest()->paginate(10);

        return api_response(ProjectsResource::collection($projects), 'List of projects');
    }

    public function addProjectForm()
    {

        $priceRange = [100000, 200000, 300000, 400000, 500000, 600000, 700000, 800000, 900000, 1000000, 1250000, 1500000, 1750000];


        $widthRange = [50, 100, 150, 200, 250, 300, 350, 400, 450, 500, 600, 700, 800, 900, 1000, 1100, 1200, 1300, 1400, 1500, 1600, 1700, 1800,
                       1900, 2000, 2500, 3000, 3500, 4000, 4500, 5000, 6000, 7000, 8000, 9000, 10000];

        $cities = City::with('regions')->get();
        $data['price_range'] = $priceRange;
        $data['width_range'] = $widthRange;
        $data['cities'] = CityResource::collection($cities);
        return api_response($data, __('Form of Add project'));
    }

    public function projectDetails($id)
    {
        $project = Project::with('comments', 'user', 'additions', 'units')->withCount('comments', 'likes')->find($id);

        if (!$project) {
            return api_response(null, __('project not found'))->setStatusCode(401);
        }
        $project->increment('views', 1);
        $otherAqars = Unit::where('region_id', $project->region->id)->with('comments', 'user', 'additions')->withCount('comments', 'likes')
                          ->take(4)->get();

        $data['project_details'] = new ProjectDetailsResource($project);
        $data['other_aqars'] = UnitsResource::Collection($otherAqars);

        return api_response($data, 'Project details');
    }

    public function commentProject(Request $request, $id)
    {
        $this->validate($request, [
            'comment' => 'required|max:255',
        ]);

        $user = auth('api')->user();
        $project = Project::find($id);

        if (!$project) {
            return api_response(null, __('This project is not found'));
        }
        $user->projectComments()->create([
                                             'project_id' => $project->id,
                                             'comment'    => $request->comment,
                                         ]);

        return api_response(null, __('Your comment has been added successfully'));
    }

    public function likeProject(Request $request, $id)
    {
        $project = Project::find($id);
        if (!$project) {
            return api_response(null, __('Not project found'), 0);
        }
        $exists = DB::table('like_project')->where(['user_id' => auth('api')->user()->id, 'project_id' => $project->id])->first();
        $toggle = auth('api')->user()->likeProjects()->toggle($project->id);

        return api_response($toggle, $exists
            ? __('project has been unliked successfully')
            :
            __('project has been liked successfully'), 1);


    }

    public function reportCommentProject(Request $request)
    {
        $this->validate($request, [
            'project_id' => 'required|exists:projects,id',
            'comment_id' => 'required|exists:project_comments,id',
        ]);
        $user = auth('api')->user();

        $project = Project::find($request->project_id);
        $comment = ProjectComment::find($request->comment_id);

        if ($comment->project_id != $project->id) {
            return api_response(null, __('Something error ,try again'));
        }
        if (!$project || !$comment) {
            return api_response(null, __('Something error ,try again'));
        }
        $exists = ProjectCommentReport::where(['project_id' => $project->id, 'comment_id' => $comment->id, 'user_id' => $user->id])->exists();

        if ($exists) {
            return api_response(null, __('You reported this comment before'));
        }

        $user->commentProjectReports()->create([
                                                   'project_id' => $project->id,
                                                   'comment_id' => $comment->id,
                                               ]);

        return api_response(null, __('Your report has been sent to administration successfully'));
    }

    public function addProjectUnits(AddProjectUnitRequest $request, $id)
    {
        $dataRequest = $request->validated();
        $user = auth('api')->user();
        $project = Project::find($id);

        if (!$project) {
            return api_response(null, __('This project is not found'));
        }

        $aqar = $project->units()->create($dataRequest);
        $aqar->code = 'Aqu0' . $aqar->id;
        $aqar->user_id = $user->id;
        $aqar->save();

        if ($request->hasFile('photos')) {
            $images = $request->file('photos');
            foreach ($images as $image) {
                MyHelper::addPhotos($image, $aqar, 'project_units', 'images');
            }

        }

        if ($request->additions) {
            $aqar->additions()->attach($request->input('additions'), []);
        }
        return api_response(null, __('Unit has been added successfully'));


    }

    public function unitDetails($id)
    {
        $unit = Unit::with('comments', 'user', 'additions')->withCount('comments', 'likes')->find($id);

        if (!$unit) {
            return api_response(null, __('unit not found'))->setStatusCode(401);
        }
        $unit->increment('views', 1);
        $otherAqars = Unit::where('region_id', $unit->region->id)->with('comments', 'user', 'additions')->withCount('comments', 'likes')
                          ->take(4)->get();

        $data['aqar_details'] = new UnitsResource($unit);
        $data['other_aqars'] = UnitsResource::Collection($otherAqars);

        return api_response($data, 'Unit details');
    }
}

?>
