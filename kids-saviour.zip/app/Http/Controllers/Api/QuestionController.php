<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\QuestionRequest;
use App\Http\Resources\AnswerResource;
use App\Http\Resources\AqarResource;
use App\Http\Resources\CityResource;
use App\Http\Resources\ContactUsResource;
use App\Http\Resources\NormalResource;
use App\Http\Resources\QuestionResource;
use App\Http\Resources\QuestionsResource;
use App\Http\Resources\RegionResource;
use App\Http\Resources\SliderResource;
use App\Http\Resources\SpecialResource;
use App\Models\Answer;
use App\Models\Aqar;
use App\Models\City;
use App\Models\Question;
use App\Models\Region;
use App\Models\Report;
use App\Models\Setting;
use Illuminate\Http\Request;


class QuestionController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth:api')->except('cities', 'answers', 'questions');
    }

    public function cities()
    {
        $cities = City::with('regions')->get();

        return api_response(CityResource::collection($cities), 'all cities');
    }

    public function addQuestion(QuestionRequest $request)
    {
        $requestData = $request->validated();
        $user = auth('api')->user();
        $user->questions()->create($requestData);

        return api_response(null, __('Your question has been added successfully'));
    }


    public function answers($id)
    {
        $question = Question::whereStatus(1)->with('answers')->find($id);
        if (!$question) {
            return api_response(null, __('no question found'));
        }
        $data['question'] = new QuestionResource($question);
        $answers = $question->answers()->latest()->paginate(10);
        $data['answers'] = AnswerResource::collection($answers);
        return api_response($data, 'all answers');
    }

    public function questions(Request $request)
    {
        if ($request->type == 'all') {
            $questionsAll = Question::when(request('type'), function ($query) {
            })->whereStatus(1)->latest()->paginate(10);
            return api_response(QuestionsResource::collection($questionsAll), 'list of questions');
        }
        $questions = Question::withCount('answers')->orderBy('answers_count', 'desc')
                             ->whereStatus(1)->latest()->take(10)->get();
        return api_response(QuestionsResource::collection($questions), 'list of questions');
    }

    public function shareAnswer(Request $request, $id)
    {
        $this->validate($request, [
            'answer' => 'required|max:150',
        ]);

        $user = auth('api')->user();
        $question = Question::find($id);

        if (!$question) {
            return api_response(null, __('This question is nou found'));
        }
        $user->answers()->create([
                                     'question_id' => $question->id,
                                     'answer'      => $request->answer,
                                 ]);

        return api_response(null, __('Your answer has been added successfully'));
    }

    public function report(Request $request)
    {
        $this->validate($request, [
            'question_id' => 'required|exists:questions,id',
            'answer_id'   => 'required|exists:answers,id',
        ]);
        $user = auth('api')->user();

        $question = Question::find($request->question_id);
        $answer = Answer::find($request->answer_id);

        if (!$question || !$answer) {
            return api_response(null, __('Something error ,try again'));
        }
        $exists = Report::where(['question_id' => $question->id, 'answer_id' => $answer->id, 'user_id' => $user->id])->exists();

        if ($exists) {
            return api_response(null, __('You reported this answer before'));
        }

        $user->reports()->create([
                                     'question_id' => $question->id,
                                     'answer_id'   => $answer->id,
                                 ]);

        return api_response(null, __('Your report has benn sent to administration successfully'));
    }

}

?>
