<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\AqarResource;
use App\Http\Resources\NormalResource;
use App\Http\Resources\ServiceResource;
use App\Http\Resources\SliderResource;
use App\Http\Resources\SpecialResource;
use App\Models\Aqar;
use App\Models\Service;
use App\Models\Setting;
use Illuminate\Http\Request;


class ServiceController extends Controller
{

//    public function __construct()
//    {
//        $this->middleware('auth:api')->except('allServices');
//    }

    public function allServices(Request $request)
    {
        $allServices = Service::latest()->get();
        return api_response(ServiceResource::collection($allServices), __('List of services'));
    }

    public function orderService(Request $request)
    {
        $service = Service::find($request->service_id);
        $this->validate($request, [
            'first_name' => 'required|max:50',
            'service_id' => 'required',
            'last_name'  => 'required|max:50',
            'phone'      => 'required|numeric|digits:11',
            'width'      => 'required_if:service_id,==,1|numeric',
            'message'    => 'required|max:250',
        ]);

        if ($service) {
            if ($service->id == 1) {
                $width = $request->width - ($request->width * 0.15);
                return api_response(['width' => $width], __('The total area of the apartment according to the contract'));
            }
            $service->orders()->create($request->all());
            return api_response(null, __('Your service request has been successfully completed'));
        }
        return api_response(null, __('Not service found'), 0);
    }

}

?>
