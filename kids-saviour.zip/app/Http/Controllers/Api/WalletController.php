<?php

namespace App\Http\Controllers\Api;

use App\Helper\MyHelper;
use App\Http\Controllers\Controller;
use App\Http\Requests\SendInvoiceRequest;
use App\Http\Resources\AqarResource;
use App\Http\Resources\NormalResource;
use App\Http\Resources\PaidAqarResource;
use App\Http\Resources\ServiceResource;
use App\Http\Resources\SliderResource;
use App\Http\Resources\SpecialResource;
use App\Models\Aqar;
use App\Models\Invoice;
use App\Models\Service;
use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class WalletController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth:api');
    }


    public function myWallet()
    {
        $user = auth('api')->user();
        $userData = [
            'id'               => $user->id,
            'username'         => $user->username,
            'phone'            => $user->phone,
            'membership_level' => __($user->membership_level),
            'wallet'           => $user->wallet,
            'points'           => $user->points,

        ];
        $data['user'] = $userData;
        $paidAqars = $user->aqars()
                          ->whereIn('package_id', [2, 3, 4, 5, 6])
                          ->when(request('code'), function ($query, $val) {
                              return $query->where('code', $val);
                          })->with('adsType', 'package')->latest()->paginate(10);
        $data['paid_aqars'] = PaidAqarResource::collection($paidAqars);
        return api_response($data, __('My Wallet'));
    }

    public function sendInvoice(SendInvoiceRequest $request)
    {
        $dataRequest = $request->validated();


        $invoice = Invoice::create($dataRequest);
        $file = $request->invoice_image;

        if ($request->invoice_image) {
            MyHelper::addPhoto($file, $invoice, 'invoice_image', 'invoices');
        }

        return api_response(null, __('Invoice added successfully'));
    }
}

?>
