<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class AddAqarRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'region_id'         => 'required|exists:regions,id',
            'aqar_kind_id'      => 'required|exists:aqar_kinds,id',
            'aqar_type_id'      => 'required_if:aqar_kind_id,1,2|exists:aqar_types,id',
            'aqar_category_id'  => 'required_if:aqar_kind_id,1,2|exists:aqar_categories,id',
            'package_id'        => 'required|exists:packages,id',
            'registered'        => 'required_if:aqar_kind_id,1,2|in:yes,no,recordable',
            'payment_method_id' => 'required|exists:payment_methods,id',
            'payment_method'    => 'required|in:cache,installment',
            'phone'             => 'required_if:aqar_kind_id,1,2|numeric',
            'lat'               => 'nullable|numeric',
            'lng'               => 'nullable|numeric',
            'name'              => 'required|array',
            'name.ar'           => 'required',
            'name.en'           => 'required',
            'description'       => 'required|array',
            'description.ar'    => 'required',
            'description.en'    => 'required',
            'price'             => 'required_if:aqar_kind_id,1,2|numeric',
            'width'             => 'required_if:aqar_kind_id,1,2|numeric',
            'photos'            => 'required',
            'photos.*'          => 'image|mimes:jpeg,jpg,png,gif,svg',
            'additions'         => 'array',
            'additions.*'       => 'nullable|exists:aqar_additions,id',
            'video_url'         => 'nullable|url',
            'rent_type'         => 'required_if:aqar_kind_id,=,2|in:monthly,annual',
            'floor'             => 'nullable|numeric',
            'bath_rooms'        => 'nullable|numeric',
            'bed_rooms'         => 'nullable|numeric',
            'building_year'     => 'nullable|numeric',
            'price_from'        => 'nullable|numeric|required_if:aqar_kind_id,=,3',
            'price_to'          => 'nullable|numeric|required_if:aqar_kind_id,=,3|gt:price_from',
            'width_from'        => 'nullable|numeric|required_if:aqar_kind_id,=,3',
            'width_to'          => 'nullable|numeric|required_if:aqar_kind_id,=,3|gt:width_from',
            'finishing_type_id' => 'required_if:aqar_kind_id,1,2|exists:finishing_types,id',
        ];
    }

    public function messages()
    {
        return [
            'price_to.gt' => __('price to field should be greater than price from field'),
            'width_to.gt' => __('width to field should be greater than width from field'),
        ];
    }
}
