<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class AddProjectRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'region_id'         => 'required|exists:regions,id',
            'lat'               => 'nullable|numeric',
            'lng'               => 'nullable|numeric',
            'title'              => 'required|array',
            'title.ar'           => 'required',
            'title.en'           => 'required',
            'description'       => 'required|array',
            'description.ar'    => 'required',
            'description.en'    => 'required',
            'photos'            => 'required',
            'photos.*'          => 'image|mimes:jpeg,jpg,png,gif,svg',
            'additions'         => 'array',
            'additions.*'       => 'nullable|exists:aqar_additions,id',
            'video_url'         => 'nullable|url',
            'price_from'        => 'nullable|numeric|required_if:aqar_kind_id,=,3',
            'price_to'          => 'nullable|numeric|required_if:aqar_kind_id,=,3|gt:price_from',
            'width_from'        => 'nullable|numeric|required_if:aqar_kind_id,=,3',
            'width_to'          => 'nullable|numeric|required_if:aqar_kind_id,=,3|gt:width_from',
        ];
    }

    public function messages()
    {
        return [
            'price_to.gt' => __('price to field should be greater than price from field'),
            'width_to.gt' => __('width to field should be greater than width from field'),
        ];
    }
}
