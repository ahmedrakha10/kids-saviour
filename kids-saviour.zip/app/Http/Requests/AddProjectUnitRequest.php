<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class AddProjectUnitRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [

            'region_id'         => 'required|exists:regions,id',
            'aqar_type_id'      => 'required|exists:aqar_types,id',
            'aqar_category_id'  => 'required|exists:aqar_categories,id',
            'finishing_type_id' => 'required|exists:finishing_types,id',
            'package_id'        => 'required|exists:packages,id',
            'payment_method_id' => 'required|exists:payment_methods,id',
            'aqar_kind_id'      => 'required|in:1,2',
            'lat'               => 'nullable|numeric',
            'lng'               => 'nullable|numeric',
            'name'              => 'required|array',
            'name.ar'           => 'required',
            'name.en'           => 'required',
            'description'       => 'required|array',
            'description.ar'    => 'required',
            'description.en'    => 'required',
            'photos'            => 'required',
            'photos.*'          => 'image|mimes:jpeg,jpg,png,gif,svg',
            'additions'         => 'array',
            'additions.*'       => 'nullable|exists:aqar_additions,id',
            'video_url'         => 'nullable|url',
            'price'             => 'required|numeric',
            'width'             => 'required|numeric',

        ];
    }

    public function messages()
    {
        return [
            'price_to.gt' => __('price to field should be greater than price from field'),
            'width_to.gt' => __('width to field should be greater than width from field'),
        ];
    }
}
