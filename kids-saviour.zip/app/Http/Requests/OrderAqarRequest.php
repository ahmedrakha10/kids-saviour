<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class OrderAqarRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }


    protected function prepareForValidation()
    {
        $this->merge(['user_id' => auth('api')->user()->id]);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'region_id'         => 'required|exists:regions,id',
            'aqar_kind_id'      => 'required|exists:aqar_kinds,id',
            'user_id'           => 'required|exists:users,id',
            'aqar_type_id'      => 'required|exists:aqar_types,id',
            'payment_method_id' => 'required_if:aqar_kind_id,=,2|exists:payment_methods,id',
            'price_from'        => 'required|numeric',
            'price_to'          => 'required|numeric|gt:price_from',
            'width_from'        => 'required|numeric',
            'width_to'          => 'required|numeric|gt:width_from',
            'rent_type'         => 'required_if:aqar_kind_id,=,2|in:monthly,annual',
        ];
    }

    public function messages()
    {
        return [
            'price_to.gt' => __('price to field should be greater than price from field'),
            'width_to.gt' => __('width to field should be greater than width from field'),
        ];
    }


}
