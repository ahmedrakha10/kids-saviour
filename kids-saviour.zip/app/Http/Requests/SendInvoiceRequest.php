<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class SendInvoiceRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    protected function prepareForValidation()
    {
        $this->merge(['user_id' => auth('api')->user()->id]);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'code'          => 'required|exists:aqars,code',
            'amount'        => 'required|numeric',
            'package_id'    => 'required|exists:packages,id',
            'user_id'           => 'required|exists:users,id',
            'invoice_image' => 'required|image|mimes:png,jpeg,jpg,svg|max:2048',
        ];
    }

}
