<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateAqarRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'region_id'         => 'exists:regions,id',
            'aqar_kind_id'      => 'exists:aqar_kinds,id',
            'aqar_type_id'      => 'exists:aqar_types,id',
            'aqar_category_id'  => 'exists:aqar_categories,id',
            'registered'        => 'in:yes,no,recordable',
            'payment_method_id' => 'required_if:aqar_kind_id,=,1|exists:payment_methods,id',
            'phone'             => 'nullable|numeric',
            'lat'               => 'nullable|numeric',
            'lng'               => 'nullable|numeric',
            'name'              => 'nullable|array',
            'name.ar'           => 'nullable',
            'name.en'           => 'nullable',
            'description'       => 'nullable|array',
            'description.ar'    => 'nullable',
            'description.en'    => 'nullable',
            'price'             => 'nullable|numeric',
            'width'             => 'nullable|numeric',
            'photos'            => 'nullable',
            'photos.*'          => 'image|mimes:jpeg,jpg,png,gif,svg',
            'additions'         => 'array',
            'additions.*'       => 'nullable|exists:aqar_additions,id',
            'video_url'         => 'nullable|url',
            'rent_type'         => 'required_if:aqar_kind_id,=,2|in:monthly,annual',
            'floor'             => 'required_if:aqar_kind_id,=,2',
            'bath_rooms'        => 'required_if:aqar_kind_id,=,2',
            'bed_rooms'         => 'required_if:aqar_kind_id,=,2',
            'building_year'     => 'required_if:aqar_kind_id,=,2|numeric',
            'finishing_type_id' => 'nullable|exists:finishing_types,id',
        ];
    }

    public function messages()
    {
        return [
            'price_to.gt' => __('price to field should be greater than price from field'),
            'width_to.gt' => __('width to field should be greater than width from field'),
        ];
    }
}
