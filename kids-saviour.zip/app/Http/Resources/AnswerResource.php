<?php

namespace App\Http\Resources;

use Illuminate\Contracts\Support\Arrayable;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class AnswerResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param Request $request
     * @return array|Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id'   => $this->id,
            'username'   => optional($this->user)->first_name . ' ' . optional($this->user)->last_name,
            'answer'   => $this->answer,
            'date'   => $this->created_at->format('d-m-Y'),
        ];
    }
}
