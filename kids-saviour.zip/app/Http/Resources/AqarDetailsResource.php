<?php

namespace App\Http\Resources;

use Illuminate\Contracts\Support\Arrayable;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class   AqarDetailsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param Request $request
     * @return array|Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $user = $this->whenLoaded('user');

        return [
            'id'             => $this->id,
            'name_ar'        => $this->getOriginal('name')['ar'],
            'name_en'        => $this->getOriginal('name')['en'],
            'description_ar' => $this->getOriginal('description')['ar'],
            'description_en' => $this->getOriginal('description')['en'],
            'images'         => $this->photos ?? [],
            'price'          => $this->price,
            'phone'          => $this->phone,
            'floor'          => $this->floor,
            'video_url'          => $this->video_url,
            'rent_type'      => __($this->rent_type),
            'registered'     => __($this->registered),
            //'aqar_type'      => $this->aqarType->name ?? null,
            //            'aqar_category'  => $this->aqarCategory->name ?? null,
            //            'aqar_kind'      => $this->aqarKind->name ?? null,
            'building_year'  => $this->building_year,
            // 'finishing_type' => $this->finishingType->name ?? null,
            'payment_method' => __($this->payment_method),
            'width'          => $this->width,
            'bed_rooms'      => $this->bed_rooms,
            'bath_rooms'     => $this->bath_rooms,
            'views'          => $this->views,
            'comments_count' => $this->comments_count ?? 0,
            'likes'          => $this->likes_count ?? 0,
            'address'        => optional($this->region)->name . ' ,' . optional($this->region->city)->name,
            'published_at'   => $this->published_at,
            'lat'            => $this->lat,
            'lng'            => $this->lng,
            'code'           => 'Aq0' . $this->id,
            'user'           => [
                'id'          => $user->id,
                'username'    => $user->first_name . ' ' . $user->last_name,
                'image'       => $user->image ? url($user->image) : null,
                'aqars_count' => $user->aqars->count() ?? 0
            ],
            'city'           => [
                'id'   => $this->region->city->id ?? null,
                'name' => $this->region->city->name ?? null,
            ],
            'region'         => [
                'id'   => $this->region->id ?? null,
                'name' => $this->region->name ?? null,
            ],
            'finishing_type' => [
                'id'   => $this->finishingType->id ?? null,
                'name' => $this->finishingType->name ?? null,
            ],
            'aqar_category'  => [
                'id'   => $this->aqarCategory->id ?? null,
                'name' => $this->aqarCategory->name ?? null,
            ],
            'aqar_kind'      => [
                'id'   => $this->aqarKind->id ?? null,
                'name' => $this->aqarKind->name ?? null,
            ],
            'aqar_type'      => [
                'id'   => $this->aqarType->id ?? null,
                'name' => $this->aqarType->name ?? null,
            ],
            'is_user_liked'  => $this->is_liked,
            'aqar_additions' => AqarAdditionResource::collection($this->whenLoaded('features')),
            'comments'       => CommentResource::collection($this->whenLoaded('comments')),
        ];
    }
}
