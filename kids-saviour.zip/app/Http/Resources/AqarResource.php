<?php

namespace App\Http\Resources;

use Carbon\Carbon;
use Illuminate\Contracts\Support\Arrayable;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class   AqarResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param Request $request
     * @return array|Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id'             => $this->id,
            'code'           => $this->code,
            'ads_type_id'           => $this->ads_type_id,
            'name'           => $this->name,
            'label'          => $this->label,
            'image'          => $this->images()->count() ? url($this->images()->first()->url) : null,
            'price'          => $this->price,
            'width'          => $this->width,
            'price_from'     => $this->price_from ?? null,
            'price_to'       => $this->price_to ?? null,
            'width_from'     => $this->width_from ?? null,
            'width_to'       => $this->width_to ?? null,
            'bed_rooms'      => $this->bed_rooms,
            'bath_rooms'     => $this->bath_rooms,
            'views'          => $this->views,
            'comments'       => $this->comments_count ?? 0,
            'likes'          => $this->likes_count ?? 0,
            'address'        => optional($this->region)->name . ' ,' . optional($this->region->city)->name,
            'status'         => $this->status,
            'project_status' => $this->project_status,
            'started_at'     => Carbon::parse($this->created_at)->format('Y-m-d'),
            'ended_at'       => Carbon::parse($this->created_at)->addMonth()->format('Y-m-d'),
        ];
    }
}
