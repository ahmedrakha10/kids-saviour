<?php

namespace App\Http\Resources;

use Carbon\Carbon;
use Illuminate\Contracts\Support\Arrayable;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class   AqarStatisticsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param Request $request
     * @return array|Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $aqarsLikes = $this->likes()
                           ->selectRaw('*,count(like_user.user_id) as total,DATE_FORMAT(like_user.created_at,"%Y-%m") as month ')
                           ->groupBy('month')
                           ->get();

        $aqarsComments = $this->comments()
                              ->selectRaw('*,count(id) as total,DATE_FORMAT(created_at,"%Y-%m") as month ')
                              ->groupBy('month')
                              ->get();

        $aqarsChats = $this->chats()
                           ->selectRaw('*,count(id) as total,DATE_FORMAT(created_at,"%Y-%m") as month ')
                           ->groupBy('month')
                           ->get();

        $totalLikes = $aqarsLikes->pluck('total');
        $LikesMonths = $aqarsLikes->pluck('month');

        $totalComments = $aqarsComments->pluck('total');
        $CommentsMonths = $aqarsComments->pluck('month');

        $totalChats = $aqarsChats->pluck('total');
        $ChatsMonths = $aqarsChats->pluck('month');


        return [
            'id'                    => $this->id,
            'code'                  => $this->code,
            'ads_type_id'           => $this->ads_type_id,
            'name'                  => $this->name,
            'label'                 => $this->label,
            'image'                 => $this->images()->count() ? url($this->images()->first()->url) : null,
            'price'                 => $this->price,
            'width'                 => $this->width,
            'price_from'            => $this->price_from ?? null,
            'price_to'              => $this->price_to ?? null,
            'width_from'            => $this->width_from ?? null,
            'width_to'              => $this->width_to ?? null,
            'bed_rooms'             => $this->bed_rooms,
            'bath_rooms'            => $this->bath_rooms,
            'views'                 => $this->views,
            'comments'              => $this->comments_count ?? 0,
            'likes'                 => $this->likes_count ?? 0,
            'chat'                  => $this->chats_count ?? 0,
            'ads_period'            => 30,
            'address'               => optional($this->region)->name . ' ,' . optional($this->region->city)->name,
            'status'                => $this->status,
            'aqar_status'           => $this->aqar_status,
            'ads_type'              => $this->package->name ?? null,
            'total_likes'           => $totalLikes,
            'total_likes_months'    => $LikesMonths,
            'total_comments'        => $totalComments,
            'total_comments_months' => $CommentsMonths,
            'total_chats'           => $totalChats,
            'total_chats_months'    => $ChatsMonths,
            'started_at'            => Carbon::parse($this->created_at)->format('Y-m-d'),
            'ended_at'              => Carbon::parse($this->created_at)->addMonth()->format('Y-m-d'),
        ];
    }
}
