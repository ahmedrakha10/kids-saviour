<?php

namespace App\Http\Resources;

use Carbon\Carbon;
use Illuminate\Contracts\Support\Arrayable;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ArticleResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param Request $request
     * @return array|Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id'             => $this->id,
            'name'          => $this->name,
            'image'          => $this->image ? asset($this->image) : null,
            'description'    => $this->description,
            'category'       => $this->aqarTip->name ?? '',
            'published_date' => Carbon::parse($this->created_at)->format('Y-m-d'),
        ];
    }
}
