<?php

namespace App\Http\Resources;

use App\Models\Chat;
use Carbon\Carbon;
use Illuminate\Contracts\Support\Arrayable;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ChatResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param Request $request
     * @return array|Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id'           => $this->id,
            'room'         => $this->room,
            'message_type' => $this->type,
            'from_user'    => $this->from_user()->first() ?? '',
            'to_user'      => $this->to_user()->first() ?? '',
            'message'      => $this->message,
            'sent_at'      => Carbon::parse($this->created_at)->format('d M Y h:i a'),
            'sent_from'    => Carbon::parse($this->created_at)->diffForHumans(),
            'not_seen'     => Chat::where('room', $this->room)->where('seen',0)->count(),
        ];
    }
}
