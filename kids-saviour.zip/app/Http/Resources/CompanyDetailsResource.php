<?php

namespace App\Http\Resources;

use Illuminate\Contracts\Support\Arrayable;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class  CompanyDetailsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param Request $request
     * @return array|Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $user = $this->whenLoaded('user');

        return [
            'id'                 => $this->id,
            'company_name'       => $this->company_name,
            'company_image'      => $this->company_image ? asset($this->company_image) : null,
            'description'        => $this->description,
            'address'            => $this->address,
            'website'            => $this->website,
            'phone'              => $this->phone,
            'facebook'           => $this->facebook,
            'instagram'          => $this->instagram,
            'linkedin'           => $this->linkedin,
            'whatsapp'           => $this->whatsapp,
            'email'              => $this->email,
            'from'               => $this->from,
            'to'                 => $this->to,
            'aqars_count'        => $this->aqars_count,
            'clients_interested' => $this->views ?? 0,
            //            'width_from'       => $this->width_from,
            'city'               => optional($this->city)->name,
            //            'project_features' => AqarAdditionResource::collection($this->whenLoaded('additions')),
            //            //            'bed_rooms'       => $this->bed_rooms,
            //            //            'bath_rooms'      => $this->bath_rooms,
            //            'views'            => $this->views,
            //            'comments_count'   => $this->comments_count ?? 0,
            //            'likes'            => $this->likes_count ?? 0,
            //
            //            //            'published_at'    => $this->published_at,
            //            //            'lat'             => $this->lat,
            //            //            'lng'             => $this->lng,
            //            'comments'         => CommentResource::collection($this->whenLoaded('comments')),
            //            'user'             => [
            //                'id'          => $user->id,
            //                'username'    => $user->first_name . ' ' . $user->last_name,
            //                'image'       => $user->image ? url($user->image) : null,
            //                'aqars_count' => $user->aqars->count() ?? 0,
            //                'location'    => $user->city->name ?? '',
            //            ],
            //            //            'is_user_liked'   => $this->is_liked,
            //
            //            //            'comments'        => CommentResource::collection($this->whenLoaded('comments')),
        ];
    }
}
