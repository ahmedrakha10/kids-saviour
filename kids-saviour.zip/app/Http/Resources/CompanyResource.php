<?php

namespace App\Http\Resources;

use Illuminate\Contracts\Support\Arrayable;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class CompanyResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param Request $request
     * @return array|Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id'               => $this->id,
            'company_name'     => $this->company_name,
            'ads_count'        => $this->aqars_count ?? 0,
            'followers_count ' => $this->views ?? 0,
            'company_image'    => $this->company_image ? asset($this->company_image) : null,

        ];
    }
}
