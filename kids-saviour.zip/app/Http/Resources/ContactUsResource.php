<?php

namespace App\Http\Resources;

use Illuminate\Contracts\Support\Arrayable;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ContactUsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param Request $request
     * @return array|Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'description' => $this->description,
            'email'       => $this->email,
            'facebook'    => $this->facebook,
            'twitter'     => $this->twitter,
            'instagram'   => $this->instagram,
            'linkedin'    => $this->linkedin,
            'youtube'     => $this->youtube,
            'tiktok'      => $this->tiktok,
        ];
    }
}
