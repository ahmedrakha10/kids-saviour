<?php

namespace App\Http\Resources;

use Illuminate\Contracts\Support\Arrayable;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class PackageResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param Request $request
     * @return array|Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id'           => $this->id,
            'name'         => $this->name,
            'period'       => $this->period,
            'position'     => $this->position ?? '',
            'views_number' => $this->views_number ?? '',
            'price'        => $this->price == 0  ?  __('free') :  (string) $this->price,
            'total_ads'    => $this->total_ads ?? 0,
            'normal_ads'   => $this->normal_ads ?? 0,
            'special_ads'  => $this->special_ads ?? 0,
            'vip_ads'      => $this->vip_ads ?? 0,
            'banner_ads'   => $this->banner_ads ?? 0,
            'type'         => $this->type ?? '',
        ];
    }
}
