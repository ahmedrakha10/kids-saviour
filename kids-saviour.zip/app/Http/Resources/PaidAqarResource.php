<?php

namespace App\Http\Resources;

use Carbon\Carbon;
use Illuminate\Contracts\Support\Arrayable;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class PaidAqarResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param Request $request
     * @return array|Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $adsType = $this->whenLoaded('adsType');
        $package = $this->whenLoaded('package');
        return [
            'id'         => $this->id,
            'code'       => $this->code ?? null,
            'ads_type'   => $adsType->name ?? null,
            'start_date' => $this->published_at ?? null,
            'end_date'   => $this->ended_at,
            'price'      => $package->price ?? 0,
            'status'     => 'تم الدفع',
        ];
    }
}
