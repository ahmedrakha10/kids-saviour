<?php

namespace App\Http\Resources;

use Illuminate\Contracts\Support\Arrayable;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class  ProjectDetailsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param Request $request
     * @return array|Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $user = $this->whenLoaded('user');

        return [
            'id'               => $this->id,
            'title'            => $this->title,
            'description'      => $this->description,
            'creation_status'  => $this->project_status,
            'images'           => $this->photos ?? [],
            'price_from'       => $this->price_from,
            'width_from'       => $this->width_from,
            'address'          => optional($this->region)->name,
            'project_features' => AqarAdditionResource::collection($this->whenLoaded('additions')),
            //            'bed_rooms'       => $this->bed_rooms,
            //            'bath_rooms'      => $this->bath_rooms,
            'views'            => $this->views,
            'comments_count'   => $this->comments_count ?? 0,
            'likes'            => $this->likes_count ?? 0,

            //            'published_at'    => $this->published_at,
            //            'lat'             => $this->lat,
            //            'lng'             => $this->lng,
            'comments'         => CommentResource::collection($this->whenLoaded('comments')),
            'user'             => [
                'id'          => $user->id,
                'username'    => $user->first_name . ' ' . $user->last_name,
                'image'       => $user->image ? url($user->image) : null,
                'aqars_count' => $user->aqars->count() ?? 0,
                'location'    => $user->city->name ?? '',
            ],
            'prices'           => [
                'price_order'    => $this->price_order,
                'for_sale'       => $this->for_sale,
                'average_prices' => $this->average_prices,
            ],
            'units'            => UnitResource::collection($this->whenLoaded('units')),
        //            'is_user_liked'   => $this->is_liked,

        //            'comments'        => CommentResource::collection($this->whenLoaded('comments')),
        ];
    }
}
