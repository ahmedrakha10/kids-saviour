<?php

namespace App\Http\Resources;

use Carbon\Carbon;
use Illuminate\Contracts\Support\Arrayable;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ProjectsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param Request $request
     * @return array|Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id'             => $this->id,
            'code'           => $this->code,
            'title'          => $this->title,
            'image'          => $this->images()->count() ? url($this->images()->first()->url) : null,
            'price_from'     => $this->price_from ?? null,
            'price_to'       => $this->price_to ?? null,
            'width_from'     => $this->width_from ?? null,
            'width_to'       => $this->width_to ?? null,
            'views'          => $this->views,
            'comments'       => $this->comments_count ?? 0,
            'likes'          => $this->likes_count ?? 0,
            'address'        => optional($this->region)->name,
            'project_status' => $this->project_status,
            'started_at'     => Carbon::parse($this->published_at)->format('Y-m-d'),
            'ended_at'       => Carbon::parse($this->published_at)->addMonth()->format('Y-m-d'),
        ];
    }
}
