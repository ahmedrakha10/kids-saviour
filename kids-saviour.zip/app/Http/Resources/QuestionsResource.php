<?php

namespace App\Http\Resources;

use App\Models\Question;
use Illuminate\Contracts\Support\Arrayable;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class QuestionsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param Request $request
     * @return array|Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id'            => $this->id,
            'username'      => optional($this->user)->first_name . ' ' . optional($this->user)->last_name,
            'image'         => optional($this->user)->image ? url(optional($this->user)->image) : null,
            'date'          => $this->created_at->format('d-m-Y'),
            'question'      => $this->question,
            'city'          => $this->region->city->name ?? null,
            'region'        => $this->region->name ?? null,
            'answers_count' => $this->answers->count() ?? 0,
        ];
    }
}
