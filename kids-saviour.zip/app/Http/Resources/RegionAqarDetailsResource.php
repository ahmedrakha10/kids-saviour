<?php

namespace App\Http\Resources;

use App\Models\Aqar;
use Illuminate\Contracts\Support\Arrayable;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class RegionAqarDetailsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param Request $request
     * @return array|Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $aqar = Aqar::find($request->segment(4));

        return [
            'id'       => $this->id,
            'name'     => $this->name,
            'selected' => $this->id == $aqar->region_id ? 1 : 0,
        ];
    }
}
