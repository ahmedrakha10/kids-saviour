<?php

namespace App\Http\Resources;

use Illuminate\Contracts\Support\Arrayable;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class SpecialResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  Request  $request
     * @return array|Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $image = [];
        $images = ImageResource::collection($this->whenLoaded('specials'));
        foreach ($images as $img) {
            array_push($image, url('uploads/aqars/'.$img->url));
        }
        return [
            'images'      => $image ?? [],
        ];
    }
}
