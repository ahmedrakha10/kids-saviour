<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Spatie\Translatable\HasTranslations;

class Aqar extends Model
{
    use HasFactory, HasTranslations;

    protected $fillable = ['id', 'region_id', 'aqar_category_id', 'payment_method', 'width', 'price', 'phone', 'code', 'lat', 'lng',
                           'user_id', 'ads_type_id', 'name', 'description', 'building_year', 'finishing_type_id', 'floor', 'bath_rooms', 'bed_rooms', 'views', 'aqar_kind_id'
                           , 'aqar_type_id', 'status', 'rent_type', 'registered', 'published_at', 'period', 'aqar_ended_at',
                           'price_from', 'price_to', 'width_from', 'width_to', 'creation_status'];
    protected $casts    = [
        'name'        => 'array',
        'description' => 'array',
    ];

    public $translatable = ['name', 'description'];

    public function additions()
    {
        return $this->hasMany(AqarAddition::class);
    }

    public function chats()
    {
        return $this->morphMany(Chat::class, 'typed');
    }

    public function aqarCategory()
    {
        return $this->belongsTo(AqarCategory::class, 'aqar_category_id');
    }

    public function finishingType()
    {
        return $this->belongsTo(FinishingType::class, 'finishing_type_id');
    }

    public function aqarType()
    {
        return $this->belongsTo(AqarType::class, 'aqar_type_id');
    }


    public function aqarKind()
    {
        return $this->belongsTo(AqarKind::class, 'aqar_kind_id');
    }


    public function paymentMethod()
    {
        return $this->belongsTo(PaymentMethod::class, 'payment_method_id');
    }


    public function comments()
    {
        return $this->hasMany(Comment::class);
    }

    public function likes()
    {
        return $this->belongsToMany(User::class, 'like_user')->withTimestamps();
    }

    public function images()
    {
        return $this->morphMany(Image::class, 'imageable')->whereType('slider');
    }

    public function adsType()
    {
        return $this->belongsTo(AdsType::class, 'ads_type_id');
    }

    public function region()
    {
        return $this->belongsTo(Region::class, 'region_id');
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function package()
    {
        return $this->belongsTo(Package::class, 'package_id');
    }

    public function features()
    {
        return $this->belongsToMany(AqarAddition::class, 'aqar_features', 'aqar_id', 'aqar_addition_id');
    }

    public function getEndedAtAttribute()
    {
        return $this->period == null
            ? Carbon::parse($this->published_at)->addMonth()->format('Y-m-d')
            :
            Carbon::parse($this->published_at)->addDays($this->period);
    }

    public function getPhotosAttribute()
    {
        $photoList = [];
        foreach ($this->images as $photo) {
            array_push($photoList, asset($photo->url));
        }
        if ($photoList) {
            return $photoList;
        }
        return null;
    }

    public function getLabelAttribute()
    {
        $label = $this->ads_type_id;
        switch ($label) {
            case 1:
                return __('normal');
            case 2:
                return __('special');
            case 3:
                return 'Vip';
            default:
                return '';
        }
    }

    public function getIsLikedAttribute()
    {
        $user = auth('api')->user();
        if ($user) {
            if (DB::table('like_user')->where(['aqar_id' => $this->id, 'user_id' => $user->id])->exists()) {
                return true;
            }
            return false;
        }
        return false;
    }

    public function getProjectStatusAttribute()
    {
        if ($this->creation_status === 'pending') {
            return __('Pending');
        } else {
            return __('completed');
        }
    }

    public function getAqarStatusAttribute()
    {
        if ($this->comments()->count() > 10) {
            return __('high');
        } else {
            return __('low');
        }
    }
}
