<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;

class AqarAddition extends Model
{
    use HasFactory, HasTranslations;

    protected $fillable = ['name','image'];
    protected $casts    = [
        'name' => 'array',
    ];

    public $translatable = ['name'];

    public function aqars()
    {
        return $this->belongsToMany(Aqar::class, 'aqar_features', 'aqar_addition_id', 'aqar_id');
    }

    public function projects()
    {
        return $this->belongsToMany(Project::class, 'project_additions', 'aqar_addition_id', 'project_id');
    }

    public function asJson($value)
    {
        return json_encode($value, JSON_UNESCAPED_UNICODE);
    }
}
