<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;

class AqarCategory extends Model
{
    use HasFactory, HasTranslations;

    protected $fillable = ['name', 'aqar_type_id'];

    protected $casts = [
        'name' => 'array',
    ];

    public $translatable = ['name'];

    public function aqarType()
    {
        return $this->belongsTo(AqarType::class, 'aqar_type_id');
    }
}
