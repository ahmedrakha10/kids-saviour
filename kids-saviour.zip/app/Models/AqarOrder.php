<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AqarOrder extends Model
{
    use HasFactory;

    protected $table    = 'aqar_orders';
    protected $fillable = ['id','aqar_kind_id', 'region_id', 'aqar_type_id', 'payment_method_id', 'price_from', 'price_to', 'width_from', 'width_to',
                           'rent_type', 'user_id'];

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function aqar_kind()
    {
        return $this->belongsTo(AqarKind::class, 'aqar_kind_id');
    }

    public function region()
    {
        return $this->belongsTo(Region::class, 'region_id');
    }

    public function aqar_type()
    {
        return $this->belongsTo(AqarType::class, 'aqar_type_id');
    }

    public function paymentMethod()
    {
        return $this->belongsTo(PaymentMethod::class, 'payment_method_id');
    }


}
