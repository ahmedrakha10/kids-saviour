<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;

class Article extends Model
{
    use HasFactory, HasTranslations;

    protected $fillable = ['name', 'description', 'aqar_tip_id', 'image'];
    protected $casts    = [
        'name'        => 'array',
        'description' => 'array',
    ];

    public $translatable = ['name', 'description'];

    public function aqarTip()
    {
        return $this->belongsTo(AqarTips::class, 'aqar_tip_id');
    }

    public function tags()
    {
        return $this->belongsToMany(Tag::class);
    }

    public function getTagssAttribute()
    {
        $tags = [];
        foreach ($this->tags as $tag) {
            array_push($tags,$tag->name);
        }
        return $tags;
    }

}
