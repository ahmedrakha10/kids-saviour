<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Chat extends Model
{
    use HasFactory;

    protected $fillable = [
        'room',
        'from_user_id',
        'to_user_id',
        'typed_id',
        'typed_type',
        'message',
        'type',
        'seen',
    ];

    public function from_user()
    {
        return $this->belongsTo(User::class, 'from_user_id')->select('id', 'first_name', 'last_name', 'image');
    }

    public function to_user()
    {
        return $this->belongsTo(User::class, 'to_user_id')->select('id', 'first_name', 'last_name', 'image');
    }

    public function scopeForme($query)
    {
        $user = auth('api')->user();
        return $query->where(function ($query) use ($user) {
            return $query->where('from_user_id', $user->id)
                         ->orWhere('to_user_id', $user->id);
        });
    }

    public function typed()
    {
        return $this->morphTo();
    }

}
