<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OrderService extends Model
{
    use HasFactory;

    //protected $table = 'order_services';

    protected $fillable = ['first_name', 'last_name', 'service_id', 'phone', 'message'];

    public function service()
    {
        return $this->belongsTo(Service::class, 'service_id');
    }
}
