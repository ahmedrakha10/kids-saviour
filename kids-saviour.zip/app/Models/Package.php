<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;

class Package extends Model
{
    use HasFactory, HasTranslations;

    protected $fillable = ['name', 'period', 'position', 'views_number', 'type', 'price', 'total_ads', 'normal_ads', 'special_ads',
                           'vip_ads', 'banner_ads'];
    protected $casts    = [
        'name'         => 'array',
        'period'       => 'array',
        'position'     => 'array',
        'views_number' => 'array',
    ];

    public $translatable = ['name', 'period', 'position', 'views_number'];

    public function asJson($value)
    {
        return json_encode($value, JSON_UNESCAPED_UNICODE);
    }

}
