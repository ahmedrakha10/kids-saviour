<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;

class Project extends Model
{
    use HasFactory, HasTranslations;

    protected $fillable = ['title', 'description', 'price_from', 'price_to', 'width_from', 'width_to', 'creation_status'
                           , 'region_id', 'lat', 'lng', 'youtube_url'];

    protected $casts = [
        'title'       => 'array',
        'description' => 'array',
    ];

    public $translatable = ['title', 'description'];


    public function images()
    {
        return $this->morphMany(Image::class, 'imageable')->whereType('slider');
    }

    public function additions()
    {
        return $this->belongsToMany(AqarAddition::class, 'project_additions', 'project_id', 'aqar_addition_id');
    }

    public function region()
    {
        return $this->belongsTo(Region::class, 'region_id');
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function comments()
    {
        return $this->hasMany(ProjectComment::class);
    }

    public function units()
    {
        return $this->hasMany(Unit::class);
    }

    public function likes()
    {
        return $this->belongsToMany(User::class, 'like_project')->withTimestamps();
    }

    public function getProjectStatusAttribute()
    {
        if ($this->creation_status === 'pending') {
            return __('Pending');
        } else {
            return __('completed');
        }
    }

    public function getPhotosAttribute()
    {
        $photoList = [];
        foreach ($this->images as $photo) {
            array_push($photoList, asset($photo->url));
        }
        if ($photoList) {
            return $photoList;
        }
        return null;
    }

    public function getPriceOrderAttribute()
    {
        $average = rand(1, 100);
        if ($average >= 85) {
            return [
                'average' => $average,
                'key'     => __('high'),
            ];
        } elseif ($average > 85 && $average < 60) {
            return [
                'average' => $average,
                'key'     => __('average'),
            ];
        } else {
            return [
                'average' => $average,
                'key'     => __('low'),
            ];
        }
    }

    public function getForSaleAttribute()
    {
        $average = rand(1, 100);
        if ($average >= 85) {
            return [
                'average' => $average,
                'key'     => __('high'),
            ];
        } elseif ($average > 85 && $average < 60) {
            return [
                'average' => $average,
                'key'     => __('average'),
            ];
        } else {
            return [
                'average' => $average,
                'key'     => __('low'),
            ];
        }
    }

    public function getAveragePricesAttribute()
    {
        $average = rand(1, 100);
        if ($average >= 85) {
            return [
                'average' => $average,
                'key'     => __('high'),
            ];
        } elseif ($average > 85 && $average < 60) {
            return [
                'average' => $average,
                'key'     => __('average'),
            ];
        } else {
            return [
                'average' => $average,
                'key'     => __('low'),
            ];
        }
    }


}
