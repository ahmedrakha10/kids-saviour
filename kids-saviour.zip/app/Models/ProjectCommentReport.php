<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProjectCommentReport extends Model
{
    use HasFactory;

    protected $table = 'project_comment_reports';

    protected $fillable = ['user_id', 'project_id', 'comment_id'];
}
