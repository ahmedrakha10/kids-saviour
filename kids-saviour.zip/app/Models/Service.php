<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;

class Service extends Model
{
    use HasFactory, HasTranslations;

    protected $fillable = ['name', 'description', 'image'];

    protected $casts = [
        'name'        => 'array',
        'description' => 'array',
    ];

    public $translatable = ['name', 'description'];

    public function orders()
    {
        return $this->hasMany(OrderService::class);
    }

    public function asJson($value)
    {
        return json_encode($value,JSON_UNESCAPED_UNICODE);
    }

}
