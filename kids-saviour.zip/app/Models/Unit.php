<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;

class Unit extends Model
{
    use HasFactory , HasTranslations;

    protected $fillable = ['id', 'region_id', 'aqar_category_id', 'project_id', 'payment_method', 'width', 'price', 'phone', 'code', 'lat', 'lng',
                           'user_id', 'ads_type_id', 'name', 'description', 'building_year', 'finishing_type_id', 'floor', 'bath_rooms', 'bed_rooms', 'views', 'aqar_kind_id'
                           , 'aqar_type_id', 'status', 'rent_type','package_id','payment_method_id', 'registered'];
    protected $casts    = [
        'name'        => 'array',
        'description' => 'array',
    ];

    public $translatable = ['name', 'description'];

    public function additions()
    {
        return $this->belongsToMany(AqarAddition::class, 'unit_additions', 'unit_id', 'aqar_addition_id');
    }

    public function images()
    {
        return $this->morphMany(Image::class, 'imageable')->whereType('slider');
    }

    public function aqarType()
    {
        return $this->belongsTo(AqarType::class, 'aqar_type_id');
    }

    public function user()
    {
        return $this->belongsTo(user::class, 'user_id');
    }

    public function region()
    {
        return $this->belongsTo(Region::class, 'region_id');
    }

    public function aqarCategory()
    {
        return $this->belongsTo(AqarCategory::class, 'aqar_category_id');
    }

    public function comments()
    {
        return $this->hasMany(UnitComment::class);
    }

    public function likes()
    {
        return $this->belongsToMany(User::class, 'unit_user')->withTimestamps();
    }

    public function getPhotosAttribute()
    {
        $photoList = [];
        foreach ($this->images as $photo) {
            array_push($photoList, asset($photo->url));
        }
        if ($photoList) {
            return $photoList;
        }
        return null;
    }


    public function getPriceOrderAttribute()
    {
        $average = rand(1, 100);
        if ($average >= 85) {
            return [
                'average' => $average,
                'key'     => __('high'),
            ];
        } elseif ($average > 85 && $average < 60) {
            return [
                'average' => $average,
                'key'     => __('average'),
            ];
        } else {
            return [
                'average' => $average,
                'key'     => __('low'),
            ];
        }
    }

    public function getForSaleAttribute()
    {
        $average = rand(1, 100);
        if ($average >= 85) {
            return [
                'average' => $average,
                'key'     => __('high'),
            ];
        } elseif ($average > 85 && $average < 60) {
            return [
                'average' => $average,
                'key'     => __('average'),
            ];
        } else {
            return [
                'average' => $average,
                'key'     => __('low'),
            ];
        }
    }

    public function getAveragePricesAttribute()
    {
        $average = rand(1, 100);
        if ($average >= 85) {
            return [
                'average' => $average,
                'key'     => __('high'),
            ];
        } elseif ($average > 85 && $average < 60) {
            return [
                'average' => $average,
                'key'     => __('average'),
            ];
        } else {
            return [
                'average' => $average,
                'key'     => __('low'),
            ];
        }
    }
}
